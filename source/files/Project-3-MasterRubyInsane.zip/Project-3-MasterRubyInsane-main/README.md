# Project-3-MasterRubyInsane

# Description
-- This project implements a Ruby-based web scraping system designed to extract, process, and display news articles from OSU’s online news portal. The system provides both interactive and automated modes to support different use cases including personal reading, data collection, and digest generation. The system employs object-oriented design with clear module separation for maintainability and scalability. It includes complete error handling, flexible user interactions, advanced parsing of article metadata, and scheduled batch processing compatible with cron jobs.
-- main.rb is responsible for Entry point, interactive interface, and mode control; Scraper.rb is responsible for HTTP requests, page navigation, error handling; Parser.rb is responsible for HTML parsing utilities for extracting data; article.rb is responsible for serving as an article object builder from raw HTML; html.rb is responsible for HTML digest generation and user filtering; request.rb is responsible for URL construction and request tracking.
-- User Instruction: a) Interactive Mode (default) Run: ruby main.rb; Display latest articles, user selects an article index, view full content or URL, optionally search by keyword and date. b)Batch Mode (compatible to cron) Run: ruby main.rb batch; Automatically fetches all available topics, scrape full articles, build and serve a full HTML digest, no user interaction required. c)HTML Digest Feedback/History Filter: After get digest generated, system prompts user for feedback, user may specify keywords to filter out unwanted topics, filtered article will be exectued from future digests.

# Managers
**Overall Project Manager:** *Anshuman Ranjan*

**Meeting Manager:** *Yunfeng Wang*

# Use Cases  
**Use Case 1:** Interactive “Read Latest”  
1. User runs ruby main.rb (defaults to interactive).  
2. System fetches and displays the latest article titles (1–N).  
3. User enters an index.  
4. System fetches that article, then prompts “View: [1] Full article, [2] URL only.”  
5. User chooses; system prints either the full article text or just its URL.  
  
**Use Case 2:** Interactive “Search by Keyword & Date”  
1. At the same prompt, user types search.  
2. System asks for a keyword and a start/end date (with sensible defaults).  
3. System pages through all matching archive pages (Scraper#scroll), extracts titles/URLs, filters by keyword and date.  
4. System lists the filtered articles.   
5. User picks one (or returns to main list).  
6. System fetches and displays that article (full or URL).  
  
**Use Case 3:** Batch HTML Digest Generation    
1. User runs ruby main.rb batch.    
2. System fetches all latest topics.  
3. For each topic, system builds an Article object.  
4. System hands the article list to Html#formatted_html and writes out Digest.html.  
5. System logs completion.  

    
# Meeting Reports
**6/5/2025 meeting**  
--Anshuman Ranjan and Sam Cubberly attended meeting in the morning, and Sam Cubberly, Yunfeng Wang, Oliver Shen, Sepehr Hooshiari attended meeting after class  
--Allocated roles project manager and meeting manager  
--brainstormed use cases before, and during the meeting, combined during meeting.   
--Set up time for the first sprint which is due by 6/7/2025 at 11:59 pm, each person has a evenly workload attribution.  
  
**6/10/2025 meeting**  
--Anshuman Ranjan, Sam Cubberly, Yunfeng Wang, and Oliver Shen attended this meeting.  
--Get sprint 2 ready which has the goal to modifiy Parser class into a module and add method to get more specific data from html payload, add Article class, modify the Scraper class to only be able to make requests, encapsulate main into function blocks and add more functionalities.  
--Discussed the due date for sprint 2 is 6/11/2025 at 11:59 pm, and formed a reasonable workload allocation.  
--Some team members were struggling with the details of the specific implementation and spent time on writing documentation for each new implements.  
  
**6/12/2025 stand-up and post stand-up**  
--All members present  
--We went through and claimed all the code smoothly.  
--get some questions like too many error_load clear during the stand_up  
--team members made sure inappropriate code was deleted.  
--get improvement on documentation and authorship like @Edit or @Refactor  
--Plan to add more functions including "Storing everything"  
  
**6/15/2025 meeting**  
--Anshuman Ranjan, Sam Cubberly, Yunfeng Wang, and Oliver Shen attended this meeting.  
--Get sprint 3 ready which includes   
    1. add three more methods @get_author, @get_date, @get_main_text to article.rb.   
    2. add function call to article class methods from main.rb by creating array of object articles, and filling array of object articles by filling the instance variables.  
    3. add function print to console in main.rb: ask user for date range (default 1 week), print “#{index}. #{article.title}” for each article in the specified date range, user selects an index to print.  
    4. integrate the batch mode interface for cron in main.rb, integrate the old main loop into @run_interactive_mode and have the batch mode @run_batch_mode.  
    5. try to build email module, including formatting and sending.  
    6. build essential test cases for all the classes, modules.  
--discuss and prepare for the final submission of Project 3  
  
  
# Contributions  
**Yunfeng Wang**  
-- build request class, with @initialzie, @to_request, @add_error methods  
-- Refactored Scraper class by adding the request instance, also refactored @make_request to make compilable  
-- updated the main flow after refactoring scraper class.  
-- add function store returned list of hash{title,url} which extracted from topics  
-- add @get_author method in article.rb  
-- build request_spec.rb with test cases to test reqeust class  
-- build scraper_spec.rb with test cases to test scraper class  
-- modify main.rb to add the batch mode export options of url of full content with cron argument support, get a new main loop to choose interactive or batch mode @main, change old main loop to @run_interactive_mode, build @run_batch_mode to handle batch scraping mode for automated runs (the cron integration).  
  
**Sepehr Hooshiari**   
-- created and initialized parser class  
-- implemented the @tag_locator function in the parser class  
-- implemented the @print_to_console function in the main class  
-- refactored code in the main class by removing segments with repeated functionality  
-- created article_spec.rb and added test cases for all functions of the article class  
-- added documentation to all implemented functions  
    
**Oliver Shen**   
-- created Parser find_topics, find_tag_content method  
-- created Scraper scroll method  
-- created main.rb and refactor the run_interactive_mode method    
-- Implement the handle_payload method in Scraper Class to check the HTTP response payload before parsing   
-- created the rest of the spec.rb and check all the test code for the last version  
    
**Anshuman Ranjan** 
-- created Article class which extracts article components from a html payload
--   - Implemented all but 2 of the methods in the class that parse the payload
-- created 2 html class methods that take the article components and write them out to an HTML-formatted file with hyperlinks (using Nokogiri HTML builder class)
-- created the error handling method in the scraper class that catches all low-level network errors that occur when sending a request and reports them to the user.
--   - the error handling class recursively sends another http request depending on the type of error it handled
-- created 3 parser methods in the Parser module which use the Nokogiri library to find specific tags, attributes, and values for use with the Article class to get specific parts of an article.
  
**Sam Cubberly**   
--Created the history instance variable in Html class
--Created the initHistory,gatherHistory, and removeArticles methods in html.rb
---	initHistory: simple string methods
---	gatherHistory: regexpressions and string methods
---	removeArticles: string methods
--Created the getTitles method in parser.rb
---	Utilized Nokogiri::HTML objects, reduce method
--Created the get Scraper class with initialize method
--Created the make_request method in scraper
---	Make Request: Utilized the Mechanize class and created requests
--Debugged in almost every part of main
--Changed run_interactive_mode, so that articles were pulled correctly from the website
--Created the loop in run_interactive mode that would allow you to see articles in real time  

  
# Sprint #1  
**6/8/2025**  
-- Created the Scraper class that uses Mechanize to GET/POST requests to "news.osu.edu"  
-- Created the Parser class that parses the HTML payload returned by a request  
-- Created the Request class that breaks URL down into it separate parts, and then combines them to a single request  
-- Created the main script that finds all the tags in a recieved payload and prints them out line-by-line  
  
# Sprint #2  
**6/10/2025**  
-- Modified Parser into a module and added methods to get more specific data from html payload  
-- Added Article class that extracts and stores the relevant Article data stored in an HTML payload  
-- Modified Scraper class to it can only make GET requests, no more POST requests  
-- Encapsulated main into function blocks  
  
# Continue sprints ...
