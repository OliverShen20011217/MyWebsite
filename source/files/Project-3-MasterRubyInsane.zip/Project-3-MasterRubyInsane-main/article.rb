#article.rb
#@author Anshuman Ranjan
#@created 6/10/25
#@description When initialized with @html_payload containing a news article, parses
#             the @html_payload using the parser class to get and store the following details of the Article:
#             - Title, Description, Author, Date, Main Text -

#@Edited 6/12/25 Oliver Shen
#@notes: add get_description method

require './parser.rb'

class Article
  include Parser
  attr_reader :url
  attr_reader :title
  attr_reader :description
  attr_reader :author
  attr_reader :date
  attr_reader :main_text

  def initialize(html_payload)
    @url = get_url(html_payload)
    @title = get_title(html_payload)
    @description = get_description(html_payload)
    @author = get_author(html_payload)
    @date = get_date(html_payload)
    @main_text = get_main_text(html_payload)
  end

  #@author Anshuman Ranjan
  #@description Parses HTML for the tag containing the Article's title
  #@uses Parser class
  #returns <String> containing the Article's title
  def get_url article_html
    find_url(article_html)
  end
  
  #@author Anshuman Ranjan
  #@description Parses HTML for the tag containing the Article's title
  #@uses Parser class
  #returns <String> containing the Article's title
  def get_title article_html
    find_by_tag_and_attr(article_html, 'div', 'class',  'title_companyprofile')[0]
  end

  #@author Oliver Shen
  #@description Parses HTML for the tag containing the Article's description
  #@uses Parser class
  #returns <String> containing the Article's subtitle
  def get_description article_html
    find_by_tag_and_attr(article_html, 'div', 'class', 'subtitle_case')[0]
  end

  #@author Yunfeng Wang
  #@description Parses HTML for the tag containing the Article's author
  #@uses Parser class
  #returns <String> containing the Article's author
  def get_author article_html
    find_by_tag_and_attr(article_html, 'div', 'class', 'pp_contactdiv_name')[0]
  end

  #@author Anshuman Ranjan
  #@description Parses HTML for the tag containing the Article's date
  #@edited Oliver Shen
  #@note: to specify the date
  #@uses Parser class
  #returns <String> containing the Article's date
  def get_date(html)
    raw = find_by_tag_and_attr(html, 'div', 'class', 'div_date_location')[0]
    parts = raw.scan(/(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/).first
    day, mon_name, year = parts
    mon = Date::MONTHNAMES.index(mon_name) || Date::ABBR_MONTHNAMES.index(mon_name)
    Date.new(year.to_i, mon, day.to_i).to_s   
  end

  #@author Anshuman Ranjan
  #@description Parses HTML for the tag containing the Article's main text
  #@uses Parser class
  #returns <String> containing the Article's main text
  def get_main_text article_html
    find_by_tag_and_attr(article_html, 'div', 'class', 'ppmodule_textblock pp_moduleblock')[0]
  end

end
