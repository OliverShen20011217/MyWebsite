# main.rb
# Created 2025-06-08 Oliver Shen
#
# This script orchestrates the full scraping workflow:
# 1. Build a Request object for the target URL
# 2. Use the Scraper class to perform an HTTP GET and validate the response
# 3. If the response is valid, initialize the Parser with the HTML
# 4. Locate all matching tags in the parsed HTML and output them
#
# Error handling:
# - If the HTTP request fails or the content is invalid, the script
#   prints the Request's error history and exits with status 1.
#
# edit 6/10/2025 Yunfeng Wang
# Updated main flow after refactoring Scraper class:
# - Scraper now maintains internal Request instance.
# - No longer passes Request object as argument to make_request.
# - Simply create Scraper instance, update URL internally, and call make_request.
# - Simplifies HTTP request logic.
#edit 6/11/2025 Yunfeng Wang
# - Added storage and display of returned list of topic hashes {title, url} after parsing topics.
# - which prepares the data for next steps in Sprint 2 the user selection, date range part and so on.
#Edit 6/11/2025 Sam Cubberly
# - added functionality so the user can choose a sub-topic
#Edit Yunfeng Wang 6/15/2025
# - Added batch mode interface for cron job integration.
# - Supports both interactive and automated batch runs like (cron).
# - In batch mode, results are automatically written to file without user input.
# Usage:
# - ruby main.rb: goes into Interactive Mode (default)
# - ruby main.rb batch: goes into Batch Mode (cron-compatible, non-interactive)
#Edit 6/16/2025 Sepehr Hooshiari
# - Added print to console funtion
# Usage:
# - user specifies date range and index, and whole article or URL gets printed to console
# Edit 6/16/2025 Oliver Shen
# - Debuggs the run_interactive_mode parts

# EDITS 6/16/2025
# Corrected the non-search portion of the interactive program. Couldn't fix the search portion in time
# Implemented html methods
# Added documentation

require_relative 'request'
require_relative 'scraper'
require_relative 'parser'
require_relative 'article'
require 'date'
require_relative 'html'
BASE_URL = 'https://news.osu.edu/'.freeze

include Parser
# Author Yunfeng Wang aat 6/15/2025
# @description The entry point of the main script. Supports both interactive mode and batch mode.
# @param ARGV[0] [String] optional mode argument ("interactive" or "batch")
# if mode is "batch", runs the scraper in non-interactive mode (cron-compatible).
# else, runs the scraper in interactive mode with user prompts.
# Edit - Sam Cubberly 6/16 changed to not prompt the user
def main
  mode = ARGV[0] || 'interactive'
  if mode == 'batch'
    run_batch_mode
  else
    run_interactive_mode
  end
end

# @author Sepehr Hooshiari - 6/16/2025
# @description Prompts user for date range and prints selected article or URL to console
# @Edit Sam Cubberly - added documentation
def print_to_console(topic_list)
  scraper = Scraper.new
  puts "Enter date range in days (default = 7): "
  days_input = gets.strip
  days = days_input.empty? ? 7 : days_input.to_i

  # Convert number of days into seconds
  cutoff = Time.now - (days * 86400)
  articles = []

  #Go through the topics and make process articles
  topic_list.each do |topic_hash|
    scraper.update_request(topic_hash[:url])
    html = scraper.make_request
    next if html.nil?

    article = Article.new(html)
    article_url = topic_hash[:url]

    begin
      article_date = Time.parse(article.get_date(html).to_s)
    rescue
      next
    end

    # Adds the article's data if within the cutoff
    if article_date >= cutoff
      article_data = {
        title: article.get_title(html),
        date: article_date,
        url: article_url,
        description: article.get_description(html),
        main_text: article.get_main_text(html),
        author: article.get_author(html)
      }
      articles << article_data
    end
  end

  if articles.empty?
    puts "No articles found within #{days} days."
    return
  end

  puts "Articles from the past #{days} days:"
  articles.each_with_index do |a, idx|
    puts "#{idx + 1}. #{a[:title]}"
  end

  puts "Select an article number:"
  choice = gets.strip.to_i
  if choice < 1 || choice > articles.size
    puts "Invalid choice."
    return
  end

  selected = articles[choice - 1]

  puts "Print 'url' or 'full content'?"
  mode = gets.strip.downcase

  if mode == "full content"
    puts "==== #{selected[:title]} ===="
    puts "Author: #{selected[:author]}"
    puts "Date: #{selected[:date]}"
    puts "Description: #{selected[:description]}"
    puts "Main Text:\n#{selected[:main_text]}"
  else
    puts "URL: #{selected[:url]}"
  end
end

# @author Oliver Shen - 6/16/2025
# Ask user for date with fallback
def parse_date_input(prompt, default)
  puts prompt
  input = gets.strip
  return default if input.empty?
  begin
    Date.parse(input)
  rescue ArgumentError
    puts "Invalid date. Using default."
    default
  end
end

# @author Oliver Shen - 6/16/2025
# Show full article or just URL
# @Edit Sam Cubberly
#	removed the URL parameter
def display_article(article)
  puts "\nView: [1] Full article, [2] URL only"
  puts ">> "
  choice = gets.strip
  if choice == "1"
    puts "\n=== ARTICLE ==="
    puts "Title: #{article.title}"
    puts "Description: #{article.description}"
    puts "Author: #{article.author}"
    puts "Date: #{article.date}"
    puts "Main Text: #{article.main_text}"
  elsif choice == "2"
    puts "\nURL: #{article.url}"
  else
    puts "Invalid input. Exiting."
  end
end

#Created 6/8/2025 Oliver Shen
#Edit 6/10/2025 Yunfeng Wang
#Edited 6/11/2025 Sam Cubberly
#@notes: puts "Choose a topic: " and sub_page will have the list of article titles and URLs
#Edit 6/15/2025 Yufeng Wang edit to "def run_interactive_mode"
#Edit 6/16/2025 Oliver Shen combine all the method together
#Edit 6/16/2025 Sepehr Hooshiari - Added call to print_to_console at the end
##Edit 6/16/2025 Oliver Shen debuggs
# @description Handles interactive scraping mode:
#   1. Fetches the latest articles list
#   2. Lets the user pick one by index, or
#   3. Search by keyword + date range (using Scraper#scroll)
#   4. Displays either the full article or just its URL
# Edit Sam Cubberly
# Debugged and fixed any issues, added documentation cause this was so hard to read
def run_interactive_mode

  #Calling to the main news page
  scraper  = Scraper.new
  base_url = 'https://news.osu.edu/'
  scraper.update_request(base_url)
  html = scraper.make_request
  if html.nil?
    puts "Failed to fetch news index page."
    exit 1
  end

  #Get a list of all the topics
  topics = Parser.find_topics(html)
  puts "Welcome to the OSU News Explorer!\n\nFound #{topics.size} topics:"
  topics.each_with_index do |t, i|
    puts "#{i + 1}. #{t[:topic]}. URL: #{t[:url]}"
  end

  # Sam Cubberly - Create an html object
  html = Html.new

  #Have the user select a topic
  loop do
    puts "\nSelect an index (1-#{topics.size}), or type 'search' to filter by keyword + date:"
    puts ">> "
    input = gets.strip.downcase

=begin
    #Using the search function
    if input == 'search'
      print "Enter keyword to search in titles: "
      keyword    = gets.strip.downcase
      start_date = parse_date_input("Enter start date (YYYY-MM-DD), or press Enter for 7 days ago: ", Date.today - 7)
      end_date   = parse_date_input("Enter end date   (YYYY-MM-DD), or press Enter for today:     ", Date.today)
      date_range = start_date..end_date
      
      #Finding all of the included titles
      scraper.update_request(base_url)
      combined_html = scraper.scroll(date_range)
      entries = getTitles(combined_html)
      keyword_matched = entries.select { |e| e['title'].downcase.include?(keyword.downcase) }
      filtered = keyword_matched.each_with_object([]) do |entry, arr|
        scraper.update_request(entry['url'])
        page_html = scraper.make_request
        next if page_html.nil?
        art = Article.new(page_html)
        begin
          art_date = Date.parse( art.date.strip )
        rescue
          next
        end
        if date_range.cover?(art_date)
          arr << { article: art, url: entry['url'], date: art_date }
        end
      end
      if filtered.empty?
        puts "No articles matched '#{keyword}' between #{start_date} and #{end_date}."
        next
      end
      puts "\nFound #{filtered.size} articles:"
      filtered.each_with_index do |h, idx|
        puts "#{idx + 1}. [#{h[:date]}] #{h[:article].title}"
      end
      
      #Loop created by Sam Cubberly
      while true do
      	print "\nSelect an article by index (1-#{filtered.size}), or 0 to print to html: "
      	choice = gets.strip.to_i
      	if choice == 0
        	html = Html.new
		digest_html = html.formatted_html( filtered )
		break

        elsif choice > filtered.size
        	puts "Invalid selection."
        	next
      	end
      	selected = filtered[choice - 1]
      	display_article(selected[:article], selected[:url])
      end
    # Edited Sam Cubberly
    # The code didn't pull from the actual topics, so I changed syntax
=end
    if input.match?(/^\d+$/) && (input.to_i <= topics.length)
      idx = input.to_i - 1
      chosen = topics[idx]
      scraper.update_request(chosen[:url])
      topic_html = scraper.make_request
   
      html.initHistory

      titles = getTitles( topic_html )

      articles = []
      titles.each do |title|
	scraper.update_request( title['url' ] )
	html = scraper.make_request
	article = Article.new(html)
	articles << article
       end

       html_obj = Html.new
       html_obj.removeArticles articles

      #Loop Created by Sam Cubbrly
      articles.each_with_index do |article, idx|
        puts "#{idx + 1}. #{article.title}"
      end


      while true do
        print "\nSelect an article by index (1-#{articles.size}), or 0 to print to html: "
        choice = gets.strip.to_i
        if choice == 0
                digest_html = html_obj.formatted_html( articles )
		            html_obj.createFile digest_html
                puts "File created: 'digest.html' in project folder"
                break
        elsif choice > articles.length
                puts "Invalid selection."
                next
        end
	selected = articles[choice - 1]
        display_article(selected)

      end
    break
    else
      puts "Invalid input. Please enter 1-#{topics.size}, or 'search'."
    end
  end
end

#author Yunfeng Wang at 6/15/2025
# @description Handles batch scraping mode for automated runs (cron integration).
# - Designed to be called by cron job or shell script for scheduled automated runs.
#
# Batch mode: fetch topics list and output based on user preference.
# Allows user to choose whether to export only URLs or full article content.
#refactored Yunfeng Wang at 6/16/2025
# - Simplified batch mode logic to always fetch full articles and output full content.
# - Integrated Html class for HTML file generation.
def run_batch_mode
  scraper = Scraper.new
  scraper.update_request('https://news.osu.edu/')
  html_payload = scraper.make_request

  if html_payload.nil?
    puts "[BATCH] Fetch failed"
    puts scraper.request.error_history.inspect
    exit 1
  end

  topics = Parser.find_topics(html_payload)
  puts "[BATCH] Extracted #{topics.size} topics"

  articles = topics.map.with_index(1) do |topic_hash, index|
    scraper.update_request(topic_hash[:url])
    article_html = scraper.make_request

    if article_html.nil?
      puts "[BATCH] Article #{index}: Failed to fetch #{topic_hash[:url]}"
      next
    end

    Article.new(article_html)
  end.compact

  html = Html.new
  html.createFile(articles)
  puts "[BATCH] HTML digest written to file: #{Html::FILENAME}"
end

if __FILE__ == $0
  main
end

