# html.rb
# @author Anshuman Ranjan 2025-6-16
# @edited Oliver Shen 2025-6-16 
# added ensure file.close if file, make sure that the content has been written and the File has been closed before returning the path
# @description 
#   The Html class is responsible for generating a personalized HTML news digest
#   from a list of Article objects. It supports:
#     - createFile(digest_html): writes the generated HTML string to disk
#     - initHistory: prompts the user for initial banned keywords
#     - gatherHistory: collects feedback on articles to ban specific words
#     - removeArticles(articles): filters out articles containing banned words
#     - formatted_html(articles): builds and returns the HTML markup for the digest
require "./article.rb"
require "nokogiri"
require "date"

require "./scraper.rb"

class Html

	FILENAME = 'Digest.html'.freeze

	attr_accessor :history

	def initialize
		@history = Hash.new { |hash, key| hash[key] = [] }
	end

	# @author Anshuman Ranjan
	# opens a file with specified filename and creates a HTML formatted news digest
	# @edited Oliver Shen
	# added ensure file.close if file, make sure that the content has been written and the File has been closed before returning the path
	# @params digest_html <String> : html code containing news digest
	# @returns <String> directory path to created file
	def createFile digest_html
		begin
			file = File.open(FILENAME, "w")
			file.write(digest_html)
			
		rescue
			puts "Unable to create HTML Digest file"
		ensure
    			file.close if file
		end
		file.path
	end

	# Created Sam Cubberly 6/16/2025
	# Determines the words that the user doesn't want in the first digest.
	def initHistory
		puts "Give a list of words / topics you don't want to see in the digest"
		puts "Type in form 'word word word'"
		gets.chomp.split.each { |key| @history[key] << [-1] }
	end

	# Created Sam Cubberly 6/16/2025
	# Determines the words that the user does not want in any future digests
	# 	stores in @history [Hash<word, [list of article indexes]]
	def gatherHistory
		puts "Rate our digest. Which articles did you not like?"
		puts "Put in form 'ArticleNumber. list of words you didn't like"
		puts "Each article number can be separated by a space or a newline. Type 'end' to end."

		reg = /(\d+. (\w+[ \n])+)/ #Gets in the form '1. word word '
		#Adds to history "word" : [ list of articles containing word ]
		while (str = gets) != "end\n"
			#Gets each word as a key, and stores a list of article indexes that the word
			# is contained in
			a = str.scan( reg ){ |a| 
				art = a[0].strip.split
				art[0].sub! '.', ''
				art.each_with_index{ |key, i| @history[key] << art[0] if i != 0}
			}
		end

		puts "Thanks for your feedback! We will make sure these topics are not included in future articles."

	end

	# Created Sam Cubberly 6/16/2025
	# Remove the articles that contain words that the user didn't want to see in their digests
	#	Using the history hash and removes these articles from the digest
	# @params articles List[article]
	def removeArticles articles
		to_remove = []
		articles.each_with_index{ |article, i|
			#Checking if a word is contained in an article
			@history.keys.each{ |bannedWord| 
				to_remove << i if (article.title.upcase.include?(bannedWord.upcase) ||
				article.description.upcase.include?(bannedWord.upcase) ||
				article.main_text.upcase.include?(bannedWord.upcase))
			}
		}
		(to_remove.size).times { |i| articles.delete_at( to_remove.reverse[i] ) }
	end

	#@author Anshuman Ranjan
	# takes each article and prints its components onto a HTML file
	# @params articles <Array[Article] : a list of Article objects to show
	# @returns <String> html code that is ready to be saved/displayed
	def formatted_html articles
		html_builder = Nokogiri::HTML::Builder.new do |doc|
			doc.html {
				doc.head {doc.title "User Digest #{Date.today}"}
				doc.body {doc.h1 "Welcome to your News Digest!"
					articles.each_with_index do |article, i|
						doc.text "Article #{i+1}:"
						doc.a(article.title, href: article.url)
						doc.p article.author
						doc.p article.date
						doc.p article.description
						doc.p "-----------------------"
						doc.p article.main_text
						doc.p "#######################"
					end
				}
			}
		end
		html_builder.to_html
	end

end
