# spec/html_spec.rb
# @author Oliver Shen - 6/16/2025
# @description rspec test for html class 
require 'nokogiri'
require 'date'
require_relative '../html'
require_relative '../article'

RSpec.describe Html do
  let(:html) { Html.new }

  # Tests that createFile writes the given HTML content to Digest.html and returns its path
  describe '#createFile' do
    let(:digest) { "<html><body>Hello, World!</body></html>" }
    let(:filename) { Html::FILENAME }

    it 'writes the given HTML string to Digest.html and returns its path' do
      path = html.createFile(digest)
      expect(path).to eq(filename)
      expect(File).to exist(path)
      expect(File.read(path)).to eq(digest)
      File.delete(path)
    end
  end

  # Tests that removeArticles filters out any articles containing banned words
  describe '#removeArticles' do
    ArticleStub = Struct.new(:title, :description, :main_text, :url)

    let(:good) { ArticleStub.new('Keep me', 'desc', 'all good here', 'u') }
    let(:bad)  { ArticleStub.new('Filter me', 'desc', 'oops banned',    'u') }

    before do
      html.history['banned'] = [0]
    end

    it 'removes any articles whose title, description, or main_text contains a banned word' do
      articles = [good, bad]
      html.removeArticles(articles)
      expect(articles.map(&:title)).to eq(['Keep me'])
    end
  end

  # Tests that formatted_html returns valid HTML including each article’s fields
  describe '#formatted_html' do
    it 'produces valid HTML containing each article’s fields' do
      stub1 = double('A1', title: 'T1', author: 'A1', date: '2025-01-01',
                    description: 'D1', main_text: 'M1', url: 'U1')
      stub2 = double('A2', title: 'T2', author: 'A2', date: '2025-02-02',
                    description: 'D2', main_text: 'M2', url: 'U2')

      html_str = html.formatted_html([stub1, stub2])
      doc = Nokogiri::HTML(html_str)

      expect(doc.at_css('title').text).to match(/User Digest \d{4}-\d{2}-\d{2}/)
      expect(doc.at_css('body h1').text).to eq('Welcome to your News Digest!')
      expect(doc.css('body a').map(&:text)).to eq(['T1', 'T2'])

      p_texts = doc.css('body p').map(&:text)
      expect(p_texts).to include('A1', '2025-01-01', 'D1', 'M1')
      expect(p_texts).to include('A2', '2025-02-02', 'D2', 'M2')
    end
  end
end
