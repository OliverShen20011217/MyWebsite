#request_spec.rb
# @Author Yunfeng Wang at 6/7/2025
# @description rspec test for request class 
# @methods initialize(url), to_request(query), add_error(code,url)

require 'uri'
require_relative 'spec_helper'
require_relative '../request'

# @Author Yunfeng Wang 6/7/2025
RSpec.describe Request do
  let(:base_url) { 'https://osu.wd1.myworkdayjobs.com/OSUCareers' }
  let(:request) { Request.new(base_url) }

  # @Author Yunfeng Wang 6/7/2025
  describe '#initialize' do
    it 'parses and stores URL components' do
      expect(request.url_components[:scheme]).to eq('https')
      expect(request.url_components[:host]).to eq('osu.wd1.myworkdayjobs.com')
      expect(request.url_components[:path]).to eq('/OSUCareers')
      expect(request.url_components[:base_url]).to eq('https://osu.wd1.myworkdayjobs.com/OSUCareers')
    end

    it 'initializes an empty error history' do
      expect(request.error_history).to be_empty
    end
  end

  # @Author Yunfeng Wang 6/7/2025
  describe '#to_request' do
    it 'returns full URL with query string' do
      full = request.to_request('q=developer')
      expect(full).to eq('https://osu.wd1.myworkdayjobs.com/OSUCareers?q=developer')
    end

    it 'returns base URL if query is nil or empty' do
        expect(request.to_request(nil)).to eq('https://osu.wd1.myworkdayjobs.com/OSUCareers')
        expect(request.to_request('')).to eq('https://osu.wd1.myworkdayjobs.com/OSUCareers')
        expect(request.to_request('   ')).to eq('https://osu.wd1.myworkdayjobs.com/OSUCareers')
    end
  end

  # @Author Yunfeng Wang 6/7/2025
  describe '#add_error' do
    it 'adds error code and url to history' do
        request.add_error(404, 'https://osu.wd1.myworkdayjobs.com/OSUCareers?q=badquery')
        expect(request.error_history).to include([404, 'https://osu.wd1.myworkdayjobs.com/OSUCareers?q=badquery'])
    end
  end
end