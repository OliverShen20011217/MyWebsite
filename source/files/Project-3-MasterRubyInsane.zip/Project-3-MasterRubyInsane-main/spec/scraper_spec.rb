# scraper_spec.rb
# @Author Yunfeng Wang 6/15/2025
# @Description:
# - tests the Scraper class functionality.
# - Managing HTTP requests through Mechanize.
# - Managing internal Request object for URL building.
# - Handling HTTP payload responses and validating response codes/content
# - Handling network errors through error_handling method
# @Methods initialize, update_request(url), make_request, handle_payload(payload), error_handling(error, payload)
# @Edited Oliver Shen 6/16/2025
# @note: add the test case for scroll method

require_relative '../parser'
require_relative '../scraper'
require_relative '../request'
require 'rspec'

RSpec.describe Scraper do
  let(:scraper) { Scraper.new }
  let(:valid_url) { "https://news.osu.edu/" }
  let(:dummy_html) { "<html><body>Test Page</body></html>" }
  let(:dummy_page) { double("Mechanize::Page", body: dummy_html, code: 200, uri: valid_url) }
  let(:dummy_payload) { double("Mechanize::Page", body: dummy_html, code: 500, uri: valid_url) }

  # @Author Yunfeng Wang 6/15/2025
  # Test initialize
  describe "#initialize" do
    it "initializes mechanize and sets request to nil" do
      expect(scraper.mechanize).not_to be_nil
      expect(scraper.request).to be_nil
    end
  end

  # @Author Yunfeng Wang 6/15/2025
  # Test update_request
  describe "#update_request" do
    it "updates internal request object" do
      scraper.update_request(valid_url)
      expect(scraper.request).to be_a(Request)
      expect(scraper.request.to_request("")).to eq(valid_url)
    end
  end

  # @Author Yunfeng Wang 6/15/2025
  # Test make_request
  describe "#make_request" do
    before do
      scraper.update_request(valid_url)
      allow(scraper.mechanize).to receive(:get).and_return(dummy_page)
    end

    it "returns payload body if request successful" do
      result = scraper.make_request
      expect(result).to eq(dummy_html)
    end

    it "handles payload failure gracefully" do
      allow(scraper).to receive(:handle_payload).and_return(nil)
      result = scraper.make_request
      expect(result).to be_nil
    end
  end

  # @Author Yunfeng Wang 6/15/2025
  # Test handle_payload
  describe "#handle_payload" do
    it "returns payload body when status code is 200 and no invalid markers" do
      result = scraper.handle_payload(dummy_page)
      expect(result).to eq(dummy_html)
    end

    it "returns nil when HTTP status is not 200" do
      bad_page = double("Mechanize::Page", body: dummy_html, code: 500, uri: valid_url)
      result = scraper.handle_payload(bad_page)
      expect(result).to be_nil
    end

    it "returns nil when invalid marker found in body" do
      bad_body = "<html><body>404 Not Found</body></html>"
      invalid_page = double("Mechanize::Page", body: bad_body, code: 200, uri: valid_url)
      result = scraper.handle_payload(invalid_page)
      expect(result).to be_nil
    end
  end

  # @Author Yunfeng Wang 6/15/2025
  # Test error_handling
  describe "#error_handling" do
    it "logs error into error_history" do
      scraper.update_request(valid_url)
      dummy_payload = double("Mechanize::Page", body: dummy_html, code: 500, uri: valid_url)

      expect { scraper.error_handling("Error", dummy_payload) }.not_to raise_error
      expect(scraper.request.error_history).to include(["Error", dummy_payload])
    end
  end

  # @Author Oliver 6/16/2025
  # Test scroll
    describe "#scroll" do
    let(:range) { Date.new(2025,1,1)..Date.new(2025,1,31) }
    let(:page_double) { double("Mechanize::Page", uri: "https://news.osu.edu/") }
    let(:body1) { "<html>PAGE1</html>" }
    let(:body2) { "<html>PAGE2</html>" }

    before do
      scraper.update_request(valid_url)

      allow(scraper.mechanize).to receive(:get).and_return(page_double)

      allow(scraper).to receive(:handle_payload).and_return(body1, body2, nil)

      allow(Parser).to receive(:find_tag_content).with(body1, 'div.pp-block-item-date-year').and_return(['2025'])
      allow(Parser).to receive(:find_tag_content).with(body1, 'div.pp-block-item-date-month').and_return(['Jan'])
      allow(Parser).to receive(:find_tag_content).with(body1, 'div.pp-block-item-date-day').and_return(['15'])

      allow(Parser).to receive(:find_tag_content).with(body2, 'div.pp-block-item-date-year').and_return(['2024'])
      allow(Parser).to receive(:find_tag_content).with(body2, 'div.pp-block-item-date-month').and_return(['Dec'])
      allow(Parser).to receive(:find_tag_content).with(body2, 'div.pp-block-item-date-day').and_return(['31'])
    end

    it "concatenates page bodies until the last article date is before range.begin" do
      concatenated = scraper.scroll(range)
      expect(concatenated).to eq(body1 + body2)
    end
  end
end
