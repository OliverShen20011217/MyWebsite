# spec/parser_spec.rb
# @author Oliver Shen
# @created 6/16/2025
# @description RSpec tests for Parser module
# @methods
#   tag_locator(raw_html)                    # instance method
#   find_tag_attributes(raw_html, tag_name)  # instance method
#   find_by_tag_and_attr(raw_html, name, key, value)  # instance method
#   find_url(raw_html)                       # instance method
#   find_topics(raw_html)                    # module method
#   getTitles(payload_body)                  # instance method
#   find_tag_content(raw_html, selector)     # module method

# spec/parser_spec.rb
require 'nokogiri'
require_relative '../parser'

RSpec.describe Parser do
  let(:html) do
    <<~HTML
      <!DOCTYPE html>
      <html>
        <head>
          <link rel="canonical" href="https://news.osu.edu/my-article-url/" />
        </head>
        <body>
          <!-- for find_topics -->
          <h2 class="title_big_headlines floatLeft">
            <a href="/first">First Article</a>
          </h2>
          <h2 class="title_big_headlines floatLeft">
            <a href="https://example.com/second">Second Article</a>
          </h2>

          <!-- for getTitles -->
          <div class="pp_bigheadlines_heading">
            <a href="/first">First Article</a>
          </div>
          <div class="pp_bigheadlines_heading">
            <a href="https://example.com/second">Second Article</a>
          </div>

          <div class="test-div" id="foo">Hello</div>
          <span class="test-span">World</span>
          <div class="pp-block-item-date-year">2025</div>
          <div class="pp-block-item-date-month">June</div>
          <div class="pp-block-item-date-day">05</div>
        </body>
      </html>
    HTML
  end

  let(:parser_inst) { Object.new.extend(Parser) }

  describe "#tag_locator" do
    it "finds raw HTML for all a, div, p, span, li tags" do
      tags = parser_inst.tag_locator(html)
      expect(tags).to include(a_string_matching(%r{<div class="test-div" id="foo">Hello</div>}))
      expect(tags).to include(a_string_matching(%r{<span class="test-span">World</span>}))
    end
  end

  describe "#find_tag_attributes" do
    it "returns an array of attribute hashes for the given tag" do
      attrs = parser_inst.find_tag_attributes(html, 'div')
      expect(attrs).to include(hash_including('class' => 'test-div', 'id' => 'foo'))
    end
  end

  describe "#find_by_tag_and_attr" do
    it "returns only the content of tags matching both name and attribute" do
      contents = parser_inst.find_by_tag_and_attr(html, 'div', 'class', 'test-div')
      expect(contents).to eq(['Hello'])
    end
  end

  describe "#find_url" do
    it "grabs the canonical link href, or nil if missing" do
      expect(parser_inst.find_url(html)).to eq('https://news.osu.edu/my-article-url/')
      without = html.sub(%r{<link rel="canonical".*?/?>}, '')
      expect(parser_inst.find_url(without)).to be_nil
    end
  end

  describe ".find_topics" do
    it "extracts topic titles and raw hrefs under h2.title_big_headlines.floatLeft a" do
      topics = Parser.find_topics(html)
      expect(topics).to match_array([
        { topic: 'First Article',  url: '/first' },
        { topic: 'Second Article', url: 'https://example.com/second' }
      ])
    end
  end

  describe "#getTitles" do
    it "returns an array of hashes with 'title' and 'url' keys from .pp_bigheadlines_heading a" do
      entries = parser_inst.getTitles(html)
      expect(entries).to match_array([
        { 'title' => 'First Article',  'url' => '/first' },
        { 'title' => 'Second Article', 'url' => 'https://example.com/second' }
      ])
    end
  end

  describe ".find_tag_content" do
    it "returns an array of the text content for a given CSS selector" do
      years  = Parser.find_tag_content(html, 'div.pp-block-item-date-year')
      months = Parser.find_tag_content(html, 'div.pp-block-item-date-month')
      days   = Parser.find_tag_content(html, 'div.pp-block-item-date-day')

      expect(years).to eq(['2025'])
      expect(months).to eq(['June'])
      expect(days).to eq(['05'])
    end

    it "returns an empty array when no elements match" do
      expect(Parser.find_tag_content(html, '.not-there')).to eq([])
    end
  end
end

