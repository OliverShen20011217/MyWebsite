# spec/main_spec.rb
# @author Oliver Shen - 6/16/2025
# @description rspec test for main class 
#   - when ARGV[0] is 'batch', it calls run_batch_mode
#   - otherwise, it calls run_interactive_mode
#
# This spec verifies all three flows:
# 1. No arguments → interactive mode
# 2. ARGV[0] == 'batch' → batch mode
# 3. Any other argument → interactive mode
require 'stringio'
require_relative '../main'

RSpec.describe 'main entrypoint' do
  before do
    allow(self).to receive(:run_interactive_mode)
    allow(self).to receive(:run_batch_mode)
  end

  context 'when no arguments are provided' do
    around do |example|
      original_argv = ARGV.dup
      ARGV.clear
      example.run
      ARGV.replace(original_argv)
    end

    it 'defaults to interactive mode' do
      expect(self).to receive(:run_interactive_mode)
      main
    end
  end

  context "when 'batch' is passed as argument" do
    around do |example|
      original_argv = ARGV.dup
      ARGV.replace(['batch'])
      example.run
      ARGV.replace(original_argv)
    end

    it 'runs batch mode' do
      expect(self).to receive(:run_batch_mode)
      main
    end
  end

  context 'when any other argument is provided' do
    around do |example|
      original_argv = ARGV.dup
      ARGV.replace(['foo'])
      example.run
      ARGV.replace(original_argv)
    end

    it 'falls back to interactive mode' do
      expect(self).to receive(:run_interactive_mode)
      main
    end
  end
end
