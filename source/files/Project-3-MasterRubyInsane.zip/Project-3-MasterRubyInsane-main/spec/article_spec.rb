#article_spec.rb
# @author Sepehr Hooshiari - 6/16/2025
# @description rspec test for article class 
# @methods initialize(html_payload), get_title(article_html), get_description(article_html)
# @Edited Oliver Shen - 6/16/2025
# @notes: added require 'date' after the change of article.rb

require 'date'
require_relative 'spec_helper'
require_relative '../article'
require_relative '../parser'

# @author Sepehr Hooshiari 6/16/2025
RSpec.describe Article do
  let(:test_html) do
    <<~HTML
      <html>
        <head>
          <link rel="canonical" href="https://news.osu.edu/my-article-url/"/>
        </head>
        <body>
          <div class="title_companyprofile">Article Title</div>
          <div class="subtitle_case">Article Subtitle</div>
          <div class="pp_contactdiv_name">Jane Doe</div>
          <div class="div_date_location">16 June 2025</div>
          <div class="ppmodule_textblock pp_moduleblock">
            This is the main article content.
          </div>
        </body>
      </html>
    HTML
  end

  subject(:article) { Article.new(test_html) }

  describe '#initialize and accessors' do
    it 'extracts the canonical URL' do
      expect(article.url).to eq("https://news.osu.edu/my-article-url/")
    end

    it 'sets the title correctly' do
      expect(article.title).to eq("Article Title")
    end

    it 'sets the description correctly' do
      expect(article.description).to eq("Article Subtitle")
    end

    it 'sets the author correctly' do
      expect(article.author).to eq("Jane Doe")
    end

    it 'parses the date into ISO format (YYYY-MM-DD)' do
      expect(article.date).to eq("2025-06-16")
    end

    it 'sets the main text correctly' do
      expect(article.main_text.strip).to eq("This is the main article content.")
    end
  end
end

