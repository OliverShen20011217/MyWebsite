#Created 6/6 Sam Cubberly
# Sends HTTP requests and manages interactions between Request and Parser.
# Edited 6/10 Yunfeng Wang
# Adds instance variable to store Request object internally inside Scraper.
# This allows the scraper to store and switch request targets flexibly.
# Methods added:
# - update_request(url): sets a new Request object with the given URL
# Edited 6/10 Oliver Shen
# scroll(date_range): paginates through pages to collect HTML for the given date range
require 'mechanize'
require_relative 'request'

class Scraper

	#Created 6/8 Sam Cubberly
	#refactored 6/10 Yunfeng Wang 
	#creates empty request holder for later URL loading
	def initialize
		@mechanize = Mechanize.new
		@request = nil
	end

	attr_accessor :mechanize, :request

	#Created 6/10 Yunfeng Wang
	# Updates the internal Request object
  # @param url [String] a base url to parse into request object
 	def update_request(url)
  	@request = Request.new(url)
	end

	#Created 6/6 Sam Cubberly
	#Sends HTTP requests and handles response
	# @Param request [Request] object
	# @Param request_type [String] == "GET" or "POST"
	# @Requires request is a completed Request object
	# @Requires request_type is a string
	# @Returns the page object or an error
	#
	#refactored 6/10 Yunfeng Wang
	# Makes HTTP request using internal Request object
  	# No longer accepts request as parameter
	# @return [String] HTML response payload or nil if request failed

	#Reverted to Sam Cubberly code - 6/12, since there were missing method calls in new version
	def make_request
		begin
			page = @mechanize.get(@request.to_request(''))
			handle_payload( page )
		rescue => error #rescue with error object "error"
			error_handling(error, page)
			nil
		end
  	end

	# Created 6/7 Oliver Shen
	# handle_payload(payload):
	# Validates the HTTP response payload before parsing
  	# 1. Verify HTTP status code is 200; log and return nil otherwise.
  	# 2. Detect pseudo-404 or access-denied markers in the HTML; log and return nil if found.
	# 3. If all checks pass, the method returns the original payload.body.
	def handle_payload (payload)
		status = payload.code.to_i
		unless status == 200
			puts "Error: HTTP returned status #{status} for URL=#{payload.uri}"
			return nil
		end
		
		invalid_markers = ["404 Not Found", "Page Not Found", "Access Denied", "Login Required"]
		if marker = invalid_markers.find { |m| payload.body.include?(m) }
			puts "Error: Page body contains invalid marker \"#{marker}\" for URL=#{payload.uri}"
			return nil
		end
		
		payload.body
	end

	#@author Anshuman Ranjan 6/8/25
	#
	#Given an error object thrown by the Mechanize class,
	#reports the error type and handles it accordingly by sending another
	#request or reporting the error
	#@param request <String> : the request sent by Mechanize
	#@param error <Object> : Any number of possible errors that can be thrown by Mechanize
	#@param payload <Mechanize::Page> OR nil : contains the return value of Mechanize
	def error_handling error, payload
		@request.add_error(error, payload)
		#If Mechanize returned a valid HTTPS status code (not nil):
		unless payload.nil?
			puts "[Error]: The HTTP request successfully returned the following status code: #{payload.code}"
		#if the request failed due to lower-level network issues:
		else
			if [Net::OpenTimeout, Net::ReadTimeout, Timeout::Error, SocketError, Errno::ECONNREFUSED].any? {|element| element.is_a? error}
				if (request.error_history.size != 0)
					puts "The network error #{error} occurred. Sending another HTTP request..."
					make_request
				else
					puts "The network error #{error} occurred. HTTP request failed."
				end
			else puts "Unknown error thrown when sending request. Recommend checking request syntax"
			end
		end
	end

	# Created 6/10 Oliver Shen
	# scroll(date_range): paginates through pages to collect HTML for the given date range
	# Edited 6/12 Oliver Shen
	# @notes: to make sure the range is YYYY-MM-DD, not only count the year before
	# @param date_range [Range<Date>] user-specified start and end dates
	# @return [String] concatenated HTML of all pages covering the date range
	def scroll(date_range)
		all_content = ''
		page_num = 1
		
		loop do
			# Update internal Request for this page number
			paged_url = "#{@request.to_request('')}?page=#{page_num}"
			update_request(paged_url)
			page = @mechanize.get(@request.to_request(''))
			body = handle_payload(page)
			break if body.nil?
			
			all_content << body
			
			years  = Parser.find_tag_content(body, 'div.pp-block-item-date-year')
			months = Parser.find_tag_content(body, 'div.pp-block-item-date-month')
			days   = Parser.find_tag_content(body, 'div.pp-block-item-date-day')
			
			if years.any? && months.any? && days.any?
				y = years.last.to_i
				# Convert the name or abbreviation of the month to a number
				m = Date::MONTHNAMES.index(months.last) || Date::ABBR_MONTHNAMES.index(months.last)
				d = days.last.to_i
				last_date = Date.new(y, m, d) rescue nil
				# If the date of the last article is earlier than the start date specified by the user, page turning will be stopped
				break if last_date && last_date < date_range.begin
			end
			
			page_num += 1
			sleep 1
		end
		
		all_content
	end

end
