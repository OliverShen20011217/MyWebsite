#parser.rb
# @author Sepehr Hooshiari
# @created 6/08/2025
# @description Extracts relevant data from returned HTML content from the Scraper module and parses through
# @methods - tag_locator(), data_returning(), page_returning()

#@edited Anshuman Ranjan 6/10/25
#@notes: changed Parser from class to module.

#UML TREE: article.rb USES parser.rb

# edit 6/10/2025 Yunfeng Wang
# refactor self_locator, tag_attributes, and find_tag_content methods to module-level methods using `self.` 
# Allows calling Parser methods directly without instantiating.

#@edited Oliver Shen 6/11/25
#@notes: add find_topics method

#@edited Sam Cubberly 6/11/25
#@notes: added getTitles method

# @Edited 6/15/25 Oliver Shen
# @notes: delete "build the full html" parts for the find_topics method which is useless 
require 'nokogiri'
require './scraper.rb'

module Parser

  # @author Sepehr Hooshiari
  # @created 6/08/2025
  # @description Parses raw_html and compiles a list containing the following tags from the HTML
  #               ['a', 'div', 'p', 'span' 'li']
  def tag_locator raw_html
    matching_tags = []
    document = Nokogiri::HTML(raw_html)
	  
    # (note: this list may need to be updated)
    tags_to_locate = ['a', 'div', 'p', 'span', 'li']

    tags_to_locate.each do |tag|
      #find all existing matches to the tag
      document.css(tag).each do |node|
        #convert matched node to HTML
	matching_tags << node.to_html
      end
    end

    matching_tags
  end

  #@author Anshuman Ranjan
  #@created 6/10/25
  #@description Parses raw_html and returns the attributes of all instances of tag_name in the code
  #@param raw_html <String> : contains all the HTML code from a website
  #@param tag_name <String> : a specific tag value that may/may not be in the HTML code
  #@returns <Array>[Hash[<String>, <String>]] : a list of tags in the HTML code that 
  #                   contain hash objects of the following pattern - [Attribute, Value]
  def find_tag_attributes raw_html, tag_name
    document = Nokogiri::HTML(raw_html)
    #holds Hashes of atrribute-value pairs
    attribute_list = []
    #For each tag, get attribute-value objects, store as string into a hash, then shovel into array
    document.css(tag_name).each {|tag| attribute_list << Hash[tag.attributes.map {|attribute, value| [attribute, value.value]}]}
    attribute_list
  end


  #@author Anshuman Ranjan
  #@created 6/10/25
  #@description Parses raw_html and returns the content under the specified tags
  #that have the specified attribute key and value in the code
  #@param raw_html <String> : contains all the HTML code from a website
  #@param tag_name <String> : a specific tag value that may/may not be in the HTML code
  #@param attr_key <String> : a specific attribute key that may/may not be in tag_name
  #@param attr_value <String> : a specific attrbitue value that may/may not be in tag_name
  #@returns <Array>[<String>] : a list of tags in the HTML code that have content
  def find_by_tag_and_attr raw_html, tag_name, attr_key, attr_value
    document = Nokogiri::HTML(raw_html)
    #holds Hashes of atrribute-value pairs
    content_list = []
    #iterate through Nodeset, and for each tag, get the content object and shovel it into the array
    document.css("#{tag_name}[#{attr_key}='#{attr_value}']").each {|tag| content_list << tag.content }
    content_list
  end

  #@author Anshuman Ranjan
  #finds the url that was used to generate the raw_html from the html payload 
  def find_url raw_html
    document = Nokogiri::HTML(raw_html)
    element = document.at_css("link[rel='canonical']")
    element ? element['href'] : nil
  end

  # @author Oliver Shen
  # @created 6/11/25
  # Parses raw_html to extract topic links from a topic list section
  # @Edited 6/11/25 Oliver Shen
  # @notes: make sure only match the link under <h2 class="t.pp_bigheadlines_heading a"> 
  # @Edited 6/15/25 Oliver Shen
  # @notes: delete "build the full html" parts which is useless 
  # @param raw_html [String] HTML content containing topic links
  # @return [Array<Hash{Symbol => String}>] list of { topic: String, url: String }
  # @edited Sam Cubberly
  # changes the css tag to be different  
  def self.find_topics(raw_html)
  	topics = []
  	doc    = Nokogiri::HTML(raw_html)

  	# Only match the link under <h2 class="title_bigheadlines floatLeft">
  	doc.css('h2.title_big_headlines.floatLeft a').each do |link_node|
	    	title = link_node.text.strip
	    	href  = link_node['href']
	    
	    	# Keep original href (relative or absolute), no manual splicing
	    	topics << { topic: title, url: href }
  	end
  	topics
  end


  #@author Sam Cubberly
  #@created 6/11/25
  # Searches through html page to return a list of article titles and their urls
  # @Param payload_body ==> the text of an html page
  # @returns [Array <title, url>] which will return the titles and urls
	
  def getTitles payload_body
	document = Nokogiri::HTML(payload_body)
	document.css('.pp_bigheadlines_heading a').reduce([]){ |titles, tags| titles << { 'title' => tags.content, 'url'=> tags['href'] } }
  end

  # @author Oliver Shen
  # @created 2025-06-16
  # @description Parses raw_html and returns the text content of all elements matching the given CSS selector.
  # @param raw_html [String] the full HTML as a string
  # @param selector [String] a Nokogiri/CSS selector, e.g. 'div.pp-block-item-date-year'
  # @return [Array<String>] list of each element's text
  def self.find_tag_content(raw_html, selector)
       doc = Nokogiri::HTML(raw_html)
       doc.css(selector).map(&:content)
  end

end

