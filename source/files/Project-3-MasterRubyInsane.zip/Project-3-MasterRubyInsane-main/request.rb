#request.rb
# @Author created 6/6/2025 By Yunfeng Wang
# @description:
# @handle URL construction, deconstruction, and error logging for HTTP requests, 
# @this class is designed to be used by the Scraper module for issuing requests and track failures
# @Methods: initialize(url), to_request(query), add_error(code,url)
require 'uri'


class Request
    attr_accessor :url_components, :error_history

    # @Author Yunfeng Wang  6/6/2025
    # Initializes a Request object by breaking the full URL into parts.
    #
    # @param url [String] the base URL string
    # @return [Request] new Request instance
    def initialize(url)
        @error_history = []

        uri = URI.parse(url)
        @url_components = {
            scheme: uri.scheme,
            host: uri.host,
            path: uri.path,
            base_url: "#{uri.scheme}://#{uri.host}#{uri.path}"
        }
    end

    # @Author Yunfeng Wang 6/6/2025
    # Builds a full URL string with the provided query.
    #
    # @param query [String] the query string to append
    # @return [String] the reconstructed full URL
    def to_request(query)
         query.to_s.strip.empty? ? @url_components[:base_url] : "#{@url_components[:base_url]}?#{query}"
    end

    # @Author Yunfeng Wang 6/7/2025
    # Logs an HTTP error into the request’s error history.
    # @param code [Integer] the HTTP error code (e.g., 404, 503)
    # @param url [String] the full URL string that caused the error
    # @return [void]
    def add_error(code, url)
        @error_history << [code, url]
    end
end