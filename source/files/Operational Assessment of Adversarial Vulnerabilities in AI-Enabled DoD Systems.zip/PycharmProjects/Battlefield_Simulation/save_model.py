#!/usr/bin/env python3
"""
save_model.py

Download and save the pretrained torchvision ResNet-18 model into the local 'models/' directory.
"""
import os
import torch
from torchvision.models import resnet18, ResNet18_Weights


def main():
    # Ensure the output directory exists
    os.makedirs('models', exist_ok=True)

    # Load pretrained ResNet-18 weights using the latest API
    weights = ResNet18_Weights.IMAGENET1K_V1
    model = resnet18(weights=weights)

    # Set the model to evaluation mode
    model.eval()

    # Save the model to disk
    save_path = os.path.join('models', 'resnet18.pt')
    torch.save(model, save_path)
    print(f"Pretrained ResNet-18 saved to {save_path}")


if __name__ == '__main__':
    main()
