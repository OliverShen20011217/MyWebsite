import ssl
import certifi

# Set up default SSL context using certifi's CA bundle to avoid certificate verification errors.
ssl_context = ssl.create_default_context(cafile=certifi.where())
ssl._create_default_https_context = lambda: ssl_context

import cv2
import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import math
import torch
import torch.nn as nn
import torchvision.models as models
import torchvision.transforms as transforms
import torchvision.transforms.functional as TF


##########################
# Simulation Platform Functions
##########################

def load_image(image_path):
    """
    Loads an image from the specified path and converts it to RGB format.

    Parameters:
        image_path (str): The file path of the image.

    Returns:
        image (numpy.ndarray): The loaded image in RGB format.
    """
    image = cv2.imread(image_path)
    if image is None:
        raise FileNotFoundError(f"Unable to load image at {image_path}. Please check the file path and integrity.")
    # Convert BGR (OpenCV default) to RGB for display.
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image


def add_gaussian_noise(image, sigma):
    """
    Add Gaussian noise to a PyTorch Tensor image.

    Args:
        image (Tensor): (C, H, W) tensor.
        sigma (float): Standard deviation of the Gaussian noise.

    Returns:
        Tensor: Noisy image.
    """
    noise = torch.randn_like(image) * (sigma / 255.0)
    noisy_image = image + noise
    noisy_image = torch.clamp(noisy_image, 0.0, 1.0)
    return noisy_image


def adjust_brightness(image, factor=1.0):
    """
    Adjusts the brightness of the image.

    Parameters:
        image (numpy.ndarray): Original image.
        factor (float): Brightness adjustment factor (<1 to darken, >1 to brighten).

    Returns:
        bright_image (numpy.ndarray): Brightness adjusted image.
    """
    bright_image = image.astype(np.float32) * factor
    bright_image = np.clip(bright_image, 0, 255).astype(np.uint8)
    return bright_image


def apply_motion_blur(image, kernel_size=15):
    """
    Applies a horizontal motion blur effect to the image.

    Parameters:
        image (numpy.ndarray): Original image.
        kernel_size (int): Size of the motion blur kernel.

    Returns:
        blurred_image (numpy.ndarray): Image after applying motion blur.
    """
    kernel = np.zeros((kernel_size, kernel_size))
    kernel[int((kernel_size - 1) / 2), :] = np.ones(kernel_size)
    kernel = kernel / kernel_size
    blurred_image = cv2.filter2D(image, -1, kernel)
    return blurred_image


def rotate_image(image, angle):
    """
    Rotate a PyTorch Tensor image (C, H, W) by the given angle.

    Args:
        image (Tensor): (C, H, W) tensor.
        angle (float): Rotation angle in degrees.

    Returns:
        Tensor: Rotated image.
    """
    # Expand batch dimension for rotation
    image = image.unsqueeze(0)  # (1, C, H, W)
    rotated = TF.rotate(image, angle, interpolation=TF.InterpolationMode.BILINEAR)
    rotated = rotated.squeeze(0)  # Remove batch dimension
    return rotated


def color_shift(image, shift_value=(20, -10, 5)):
    """
    Applies a color shift to the image.

    Parameters:
        image (numpy.ndarray): Original image.
        shift_value (tuple): Shift values for each RGB channel.

    Returns:
        shifted_image (numpy.ndarray): Color shifted image.
    """
    shifted = image.astype(np.float32)
    for i in range(3):
        shifted[:, :, i] += shift_value[i]
    shifted = np.clip(shifted, 0, 255).astype(np.uint8)
    return shifted


def add_occlusion(image, top_left, size, color=(0, 0, 0)):
    """
    Adds a rectangular occlusion to the image to simulate an obstruction.

    Parameters:
        image (numpy.ndarray): Original image.
        top_left (tuple): The (x, y) coordinate for the top-left corner of the occlusion.
        size (tuple): (width, height) of the occlusion rectangle.
        color (tuple): The color of the occlusion (default is black).

    Returns:
        occluded_image (numpy.ndarray): Image with occlusion applied.
    """
    occluded_image = image.copy()
    x, y = top_left
    w, h = size
    occluded_image[y:y + h, x:x + w] = color
    return occluded_image


def simulate_environment(image, config):
    """
    Applies a sequence of interference effects to simulate a battlefield-like environment.

    Parameters:
        image (numpy.ndarray): Original image.
        config (dict): Configuration dictionary for each interference effect.

    Returns:
        processed_img (numpy.ndarray): Image after applying the simulation effects.
    """
    processed_img = image.copy()
    if config.get("noise", {}).get("enabled", False):
        noise_conf = config["noise"]
        processed_img = add_gaussian_noise(processed_img, mean=noise_conf.get("mean", 0),
                                           sigma=noise_conf.get("sigma", 25))
    if config.get("brightness", {}).get("enabled", False):
        brightness_conf = config["brightness"]
        processed_img = adjust_brightness(processed_img, factor=brightness_conf.get("factor", 1.0))
    if config.get("blur", {}).get("enabled", False):
        blur_conf = config["blur"]
        processed_img = apply_motion_blur(processed_img, kernel_size=blur_conf.get("kernel_size", 15))
    if config.get("rotate", {}).get("enabled", False):
        rotate_conf = config["rotate"]
        processed_img = rotate_image(processed_img, angle=rotate_conf.get("angle", 5))
    if config.get("color_shift", {}).get("enabled", False):
        cs_conf = config["color_shift"]
        processed_img = color_shift(processed_img, shift_value=cs_conf.get("shift_value", (20, -10, 5)))
    if config.get("occlusion", {}).get("enabled", False):
        occ_conf = config["occlusion"]
        processed_img = add_occlusion(processed_img, top_left=occ_conf.get("top_left", (0, 0)),
                                      size=occ_conf.get("size", (50, 50)), color=occ_conf.get("color", (0, 0, 0)))
    return processed_img


# Extended configuration dictionary including all simulation effects.
config = {
    "noise": {"enabled": True, "mean": 0, "sigma": 30},
    "brightness": {"enabled": True, "factor": 0.8},
    "blur": {"enabled": True, "kernel_size": 15},
    "rotate": {"enabled": True, "angle": 5},
    "color_shift": {"enabled": True, "shift_value": (20, -10, 5)},
    "occlusion": {"enabled": False}  # Set to True to enable occlusion effect.
}


##########################
# FGSM Adversarial Attack Functions
##########################

def fgsm_attack(model, loss_fn, image, label, epsilon):
    """
    Generates an adversarial example using the Fast Gradient Sign Method (FGSM).

    Parameters:
        model: Pre-trained model.
        loss_fn: Loss function (e.g., nn.CrossEntropyLoss()).
        image (torch.Tensor): Input image tensor.
        label (torch.Tensor): True label tensor.
        epsilon (float): Perturbation magnitude.

    Returns:
        adv_image (torch.Tensor): Adversarial image.
    """
    image.requires_grad = True
    output = model(image)
    loss = loss_fn(output, label)
    model.zero_grad()
    loss.backward()
    data_grad = image.grad.data.sign()
    adv_image = image + epsilon * data_grad
    adv_image = torch.clamp(adv_image, 0, 1)
    return adv_image


def test_adversarial_attack(simulated_img):
    """
    Tests FGSM attack on a simulated image and displays the adversarial example.

    Parameters:
        simulated_img (numpy.ndarray): Simulated image from the environment.
    """
    # Define transformation: convert image to tensor and normalize
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])
    tensor_img = transform(simulated_img).unsqueeze(0)  # Shape: (1, C, H, W)

    # Load a pre-trained ResNet18 model.
    model = models.resnet18(pretrained=True)
    model.eval()

    # Use a dummy label (e.g., class 281 for tabby cat in ImageNet)
    label = torch.tensor([281])
    loss_fn = nn.CrossEntropyLoss()

    # Generate the adversarial example with FGSM
    adv_tensor = fgsm_attack(model, loss_fn, tensor_img, label, epsilon=0.02)

    # Inverse normalization for display: note this is a quick approximation.
    inv_normalize = transforms.Normalize(
        mean=[-0.485 / 0.229, -0.456 / 0.224, -0.406 / 0.225],
        std=[1 / 0.229, 1 / 0.224, 1 / 0.225]
    )
    adv_tensor = inv_normalize(adv_tensor.squeeze(0))
    adv_image = adv_tensor.detach().cpu().numpy().transpose(1, 2, 0)
    adv_image = np.clip(adv_image, 0, 1)

    plt.imshow(adv_image)
    plt.title("Adversarial Example (FGSM)")
    plt.axis("off")
    plt.show()


##########################
# Main Section: Testing and Display
##########################

if __name__ == "__main__":
    # Define a list of image file names; ensure these files exist in your project directory.
    image_paths = ["pic1.jpg", "pic2.jpg", "pic3.jpg"]

    original_images = []
    simulated_images = []

    for path in image_paths:
        try:
            img = load_image(path)
            original_images.append(img)
            sim_img = simulate_environment(img, config)
            simulated_images.append(sim_img)
        except Exception as e:
            print(f"Error loading {path}: {e}")

    # Display each original image alongside its simulated version.
    n = len(original_images)
    plt.figure(figsize=(12, 4 * n))
    for i in range(n):
        plt.subplot(n, 2, 2 * i + 1)
        plt.imshow(original_images[i])
        plt.title(f"Original Image {i + 1}")
        plt.axis("off")

        plt.subplot(n, 2, 2 * i + 2)
        plt.imshow(simulated_images[i])
        plt.title(f"Simulated Image {i + 1}")
        plt.axis("off")

    plt.tight_layout()
    plt.show()

    # Optionally, run FGSM adversarial attack on the first simulated image.
    if simulated_images:
        test_adversarial_attack(simulated_images[0])
