Operational Assessment of Adversarial Vulnerabilities in AI-Enabled DoD Systems
Abstract
This project evaluates the robustness of AI vision models under battlefield-like environmental conditions combined with adversarial attacks.
A simulation platform was developed to apply environmental distortions (Gaussian noise, rotation) and generate adversarial examples using the Fast Gradient Sign Method (FGSM).

Project Structure
Battlefield_Simulation/
├── attack.py              # FGSM attack generation
├── run_experiments.py      # Batch simulation and attack pipeline
├── simulation.py           # Environmental distortion simulation
├── save_model.py           # Save pretrained ResNet-18 model
├── models/                 # Folder containing saved models
├── images/                 # Folder with original input images
├── outputs/                # Folder where output images are saved
├── results/                # Folder where results.csv is saved
├── requirements.txt        # Python dependencies
├── README.md               # Project description and instructions
Environment Setup
(Optional) Create a virtual environment:
python3 -m venv venv
source venv/bin/activate
Install required dependencies:
pip install -r requirements.txt
How to Run the Project

Step 1: Save the Pretrained Model
Download and save a pretrained ResNet-18 model:
python save_model.py
Model will be saved at models/resnet18.pt.

Step 2: Prepare Input Images
Place your original .jpg or .png images inside the images/ directory.
These will be automatically resized and center-cropped before processing.

Step 3: Run Simulation and FGSM Attack
Execute:
python run_experiments.py \
  --input_dir images \
  --output_dir outputs \
  --model_path models/resnet18.pt \
  --csv_path results/results.csv
This script will:

Apply environmental effects (Gaussian noise, rotation)

Generate FGSM adversarial examples

Save all output images into outputs/

Save experiment logs into results/results.csv

Output Description
Simulated Images: Battlefield-distorted versions of original images.

Adversarial Images: FGSM-perturbed versions of distorted images.

Results CSV: Includes NoiseSigma, RotationAngle, Original and Adversarial predictions and confidence scores.

Example from results.csv:


ID	InputImage	NoiseSigma	RotationAngle	Epsilon	OriginalLabel	OriginalConf	AdvLabel	AdvConf
0	pic1.jpg	10	0	0.02	979	0.62	123	0.37
Notes and Limitations
Security Warning: PyTorch will display a warning related to model loading security. This project uses trusted torchvision models.

Limitations: Only simple environmental effects and basic FGSM attacks are implemented. Future work can explore more complex distortions (e.g., fog, rain) and stronger attacks (e.g., PGD, CW).

Contact Information
Author: Oliver Shen
Email: shen.1648@osu.edu

