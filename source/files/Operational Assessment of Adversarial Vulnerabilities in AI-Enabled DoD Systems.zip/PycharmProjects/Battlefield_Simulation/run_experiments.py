#!/usr/bin/env python3
"""
run_experiments.py

Batch script to simulate battlefield distortions + generate FGSM adversarial examples
and log results to CSV.
"""
import os
import csv
import torch
import argparse
import torchvision.transforms as transforms
from torchvision import models
from PIL import Image
from simulation import add_gaussian_noise, apply_motion_blur, rotate_image, adjust_brightness, color_shift
from attack import fgsm_attack


def load_image(path):
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
    ])
    img = Image.open(path).convert('RGB')
    return preprocess(img)


def save_tensor_image(tensor, path):
    transforms.ToPILImage()(tensor.cpu()).save(path)


def main():
    parser = argparse.ArgumentParser(description='Run Battlefield Simulation Experiments')
    parser.add_argument('--input_dir', type=str, required=True, help='Directory of input images')
    parser.add_argument('--output_dir', type=str, required=True, help='Directory to save outputs')
    parser.add_argument('--model_path', type=str, required=True, help='Path to pretrained model')
    parser.add_argument('--epsilon', type=float, default=0.02, help='FGSM epsilon value')
    parser.add_argument('--csv_path', type=str, required=True, help='CSV file to save experiment logs')
    args = parser.parse_args()

    noise_levels = [10, 20, 30, 50]
    rotations = [0, 5, 10]

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = torch.load(args.model_path, map_location=device)
    model.eval()

    os.makedirs(args.output_dir, exist_ok=True)

    # Prepare CSV
    csv_file = open(args.csv_path, mode='w', newline='')
    writer = csv.writer(csv_file)
    writer.writerow(['ID', 'InputImage', 'NoiseSigma', 'RotationAngle', 'Epsilon',
                     'OriginalLabel', 'OriginalConf', 'AdvLabel', 'AdvConf',
                     'SimulatedImagePath', 'AdversarialImagePath'])

    id_counter = 0
    for filename in os.listdir(args.input_dir):
        if not (filename.endswith('.png') or filename.endswith('.jpg')):
            continue

        input_path = os.path.join(args.input_dir, filename)
        base_name = os.path.splitext(filename)[0]

        original_img = load_image(input_path).unsqueeze(0).to(device)  # Add batch dimension

        with torch.no_grad():
            orig_output = model(original_img)
            orig_pred = orig_output.argmax(dim=1).item()
            orig_conf = torch.softmax(orig_output, dim=1)[0, orig_pred].item()

        for sigma in noise_levels:
            for theta in rotations:
                # Simulate battlefield effects
                img = original_img.squeeze(0).cpu()
                img = add_gaussian_noise(img, sigma)
                img = rotate_image(img, theta)
                # (Other effects like brightness/color shift can be added here)

                sim_save_path = os.path.join(args.output_dir, f'{base_name}_noise{sigma}_rot{theta}.png')
                save_tensor_image(img, sim_save_path)

                # Prepare for attack
                img_input = img.unsqueeze(0).to(device)

                # Generate adversarial example
                adv_img = fgsm_attack(model, img_input, torch.tensor([orig_pred]).to(device), args.epsilon, device)
                adv_save_path = os.path.join(args.output_dir, f'{base_name}_adv_noise{sigma}_rot{theta}.png')
                save_tensor_image(adv_img.squeeze(0), adv_save_path)

                # Model output on adversarial example
                adv_output = model(adv_img)
                adv_pred = adv_output.argmax(dim=1).item()
                adv_conf = torch.softmax(adv_output, dim=1)[0, adv_pred].item()

                # Write to CSV
                writer.writerow([id_counter, filename, sigma, theta, args.epsilon,
                                 orig_pred, orig_conf, adv_pred, adv_conf,
                                 sim_save_path, adv_save_path])

                id_counter += 1

    csv_file.close()
    print(f"Experiments finished. Results saved to {args.csv_path}")


if __name__ == '__main__':
    main()
