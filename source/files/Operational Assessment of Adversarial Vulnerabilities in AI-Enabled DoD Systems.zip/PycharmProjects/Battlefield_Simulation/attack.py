import torch
import torch.nn.functional as F
from torchvision.utils import save_image


def fgsm_attack(model: torch.nn.Module,
                data: torch.Tensor,
                target: torch.Tensor,
                epsilon: float,
                device: torch.device = torch.device('cpu')) -> torch.Tensor:
    """
    Performs the Fast Gradient Sign Method attack on a single batch of images.

    Args:
        model: Pretrained PyTorch model in evaluation mode.
        data: Input tensor of shape (N, C, H, W), values in [0, 1].
        target: True labels tensor of shape (N,).
        epsilon: Attack strength (float scalar).
        device: Torch device (cpu or cuda).

    Returns:
        perturbed_data: Adversarial examples tensor with same shape as data.
    """
    # Ensure model is in eval mode
    model.eval()

    # Move data and target to device
    data, target = data.to(device), target.to(device)

    # Set requires_grad attribute of tensor. Important for FGSM
    data.requires_grad = True

    # Forward pass
    output = model(data)
    # Calculate loss
    loss = F.cross_entropy(output, target)

    # Zero all existing gradients
    model.zero_grad()

    # Backward pass
    loss.backward()

    # Collect the gradient of the input data
    data_grad = data.grad.data

    # Create the perturbed image by adjusting each pixel
    perturbed_data = data + epsilon * data_grad.sign()

    # Clamp to maintain [0,1] range
    perturbed_data = torch.clamp(perturbed_data, 0, 1)

    return perturbed_data


def save_adversarial_images(tensor: torch.Tensor,
                            filenames: list[str],
                            out_dir: str) -> None:
    """
    Saves each image tensor in a batch to disk.

    Args:
        tensor: Tensor of shape (N, C, H, W) with pixel values in [0,1].
        filenames: List of base filenames (without directory).
        out_dir: Directory path where images will be saved.
    """
    tensor = tensor.cpu()
    for img, name in zip(tensor, filenames):
        # Construct full output path
        path = f"{out_dir}/{name}"
        # Save image (will convert from [C,H,W] to standard image format)
        save_image(img, path)


if __name__ == '__main__':
    import argparse
    from torchvision import transforms
    from PIL import Image

    parser = argparse.ArgumentParser(description='FGSM Attack Utility')
    parser.add_argument('--model-path', type=str, required=True, help='Path to pretrained model .pt file')
    parser.add_argument('--input', type=str, required=True, help='Path to input image (PNG/JPG)')
    parser.add_argument('--label', type=int, required=True, help='True label index for the input')
    parser.add_argument('--epsilon', type=float, default=0.02, help='Attack strength')
    parser.add_argument('--output', type=str, required=True, help='Path to save adversarial image')
    args = parser.parse_args()

    # Load model
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = torch.load(args.model_path, map_location=device)
    model.to(device)

    # Preprocessing for ImageNet
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
    ])

    # Open image
    img = Image.open(args.input).convert('RGB')
    data = preprocess(img).unsqueeze(0)  # Add batch dim

    # Run FGSM
    data_adv = fgsm_attack(model, data, torch.tensor([args.label]), args.epsilon, device)

    # Save adversarial image
    save_adversarial_images(data_adv, [args.output.split('/')[-1]], '/'.join(args.output.split('/')[:-1]))

    print(f"Adversarial image saved to {args.output}")
