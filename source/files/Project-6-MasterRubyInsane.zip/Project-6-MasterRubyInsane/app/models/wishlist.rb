=begin
	Created Sam Cubberly 7/19/2025
	Have a foreign key to the User
		and needs a non-null, unique value for the book
=end
class Wishlist < ApplicationRecord
	#belongs_to :user
	#belongs_to :book_information

	#Formatting the constraints correctly
	validates :user, presence: true, format: { with: /[a-z]+\.[1-9][0-9]*/ }
	validates :isbn, presence: true, length: { maximum: 17 }, uniqueness: true

end
