class User < ApplicationRecord
  has_many :book_listings, dependent: :destroy # ceate by oliver just make sure everytime user ceater a list, the user information will auto connect to it
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  # @author Sam Cubberly
  # Creating a relationship with book purchases 
  has_many :book_purchases, inverse_of: "seller"
  has_many :book_purchases, inverse_of: "buyer"

  # @author Anshuman Ranjan
  # Ensures first_name, last_name, and email are filled.
  # Ensures email is unique in the model
  # Ensures the email is from the domain @osu.edu
  validates :first_name, :last_name, :email, presence: true
  validates :email, uniqueness: true
  validates :email, format: { with: /\A[\w.+-]+\d*@osu\.edu\z/, message: "must be an @osu.edu email" }

  # extracts the users lastname.number from email and stores it in the osu_id field
  before_save :set_osu_id

  # debugging
  before_validation :debug_fields

  private
  def debug_fields
    puts "DEBUG: first_name = #{first_name}, last_name = #{last_name}"
  end

  def set_osu_id
    self.osu_id = email.split("@").first.downcase if email.present?
  end
end
