# @author Oliver Shen 7/19/2025

# app/models/book_listing.rb

# == Model: BookListing
#
# This model represents a listing of a book posted by a user on the Buckeye Book Bazaar platform.
# Each listing includes key information such as the book's ISBN, price, condition, picture and the user who created it.
#
# Validations and additional business logic can be added as needed.
class BookListing < ApplicationRecord
  belongs_to :user
  has_one_attached :picture
  validates :user, presence: true

  # limit the format and size of image
  validate :acceptable_picture

  def acceptable_picture
    return unless picture.attached?

    unless picture.content_type.in?(%w[image/jpeg image/png image/jpg])
      errors.add(:picture, "must be a JPEG or PNG")
    end

    if picture.byte_size > 2.megabytes
      errors.add(:picture, "is too big. Max size is 2MB.")
    end
  end
end
