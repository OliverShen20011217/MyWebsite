=begin
	Created by Sam Cubberly 7/19/2025
	Needs listing, pickuplocation, buyerName to all be non-null
		buyername and pickuplocation don't need to be unique
=end

class BookPurchase < ApplicationRecord
	belongs_to :buyer, class_name: "User", foreign_key: "buyer_id"
	belongs_to :seller, class_name: "User", foreign_key: "seller_id"
	belongs_to :book, class_name: "BookInformation", foreign_key: "book_id"
	
	#Added the validations to it
	validates :pickupLocation, presence: true, length: { maximum: 50 }
	validates :buyer_id, presence: true
	validates :seller_id, presence: true
	validates :book_id, presence: true
	validates :price, presence: true
end
