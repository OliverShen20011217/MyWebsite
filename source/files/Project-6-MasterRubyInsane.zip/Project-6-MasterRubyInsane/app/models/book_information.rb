class BookInformation < ApplicationRecord

	# @edited Sam Cubberly 7/22/2025
	has_many :book_purchases, inverse_of "book"

end
