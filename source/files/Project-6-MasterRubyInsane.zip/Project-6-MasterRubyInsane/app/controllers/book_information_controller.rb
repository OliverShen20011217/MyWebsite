# Author Yunfeng Wang 07/18/2025
# app/controllers/book_informations_controller.rb

class BookInformationController < ApplicationController
  # Display all book records
  def index
    @books = BookInformation.all
  end

  # display book details
  def show
    @book = BookInformation.find(params[:id])
  end

  # Render form to create new book
  def new
    @book = BookInformation.new
  end

  # commit new book record
  def create
    @book = BookInformation.new(book_params)
    if @book.save
      redirect_to @book, notice: "Book was successfully created."
    else
      render :new, status: :unprocessable_entity
    end
  end

  # Render form to edit book
  def edit
    @book = BookInformation.find(params[:id])
  end

  # update book information
  def update
    @book = BookInformation.find(params[:id])
    if @book.update(book_params)
      redirect_to @book, notice: "Book was successfully updated."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  # delete record
  def destroy
    @book = BookInformation.find(params[:id])
    @book.destroy
    redirect_to book_informations_path, notice: "Book was deleted."
  end

  private

  # allow only permitted fields
  def book_params
    params.require(:book_information).permit(:isbn, :title, :author, :genre, :description, :keywords, :categories)
  end
end
