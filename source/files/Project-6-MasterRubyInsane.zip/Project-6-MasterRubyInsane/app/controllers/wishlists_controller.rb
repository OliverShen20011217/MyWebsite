#Created Sam Cubberly 7/19/2025
#Used as the controller for the wishlist

class WishlistsController < ApplicationController
  def new
	@wishlist = Wishlist.new
  end

  #Created 7/19 to show the wishlist
  def index
	@wishlists = Wishlist.all
	@bookInfos = BookInformation.all  
  end

  def show
	@wishlist = Wishlist.find(params[:id])
	if @wishlist.nil?
		redirect_to action: :index
	end
  end

  #Created 7/19 to create an entry to the wishlists
  def create
	@wishlist = Wishlist.new(wishlist_params)
	if @wishlist.save
		redirect_to @wishlist, notice: "Success!"
	else
		render :new
	end
  end

  def destroy
	#Destroying the correct entry!
	wishlist = Wishlist.find(params[:id])
	wishlist.destroy
  end

  #Created 7/19 to do parameters
  # Good Source https://guides.rubyonrails.org/form_helpers.html
  private
  def wishlist_params
	params.require(:wishlist).permit(:user, :isbn)
  end
end
