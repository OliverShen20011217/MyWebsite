#Created by Sam cubberly 7/19/2025
#Intention of showing all books that have been purchased

class BookPurchasesController < ApplicationController
  def new
	@book_purchase = BookPurchase.new
  end

  #Variables so I can show the purchase
  def index
	@book_purchases = BookPurchase.all
  end

  def show
	@book_purchase = BookPurchase.find(params[:id])
	if @book_purchase.nil?
		redirect_to action: :index
	end
  end

  def create
	@book_purchase = BookPurchase.new(book_purchase_params)
	if @book_purchase.save
		redirect_to @book_purchase, notice: "Success!"
	else
		render :new
	end
  end

  def destroy
	book_purchase = BookPurchase.find(params[:id])
	book_purchase.destroy
  end

  private
  def book_purchase_params
	params.require(:book_purchase).permit(:price, :book_id, :pickupLocation, :buyer_id, :seller_id )
  end
end
