class ApplicationController < ActionController::Base
  # Only allow modern browsers supporting webp images, web push, badges, import maps, CSS nesting, and CSS :has.
  allow_browser versions: :modern

  # @author Anshuman Ranjan
  before_action :configure_permitted_parameters, if: :devise_controller?

  # protected method that registers custom fields in the USER model for the Devise controller to use.
  # When devise inherits from ApplicationController class, it will call this function to know that these USER fields are safe to access
  # and populate when a new website user fills in data to add to the table
  protected

  def configure_permitted_parameters
    keys = [ :first_name, :last_name, :phone, :address ]
    devise_parameter_sanitizer.permit(:sign_up, keys: keys)
    devise_parameter_sanitizer.permit(:account_update, keys: keys)
  end
  # dont add public/private methods below without explicit declaration
  # end of contributions Anshuman Ranjan #

  # Author Yunfeng Wang
  # After register at landing page, automatically logout and jump back to landing page
  # user need to log in after signing up
  def after_sign_up_path_for(resource)
    sign_out(resource) 
    landing_index_path 
  end

  # after log in successfully, go to homepage.
  def after_sign_in_path_for(resource)
    home_index_path
  end
  # end of Yunfeng Wang's work

end
