# Author Yunfeng Wang 07/20/2025
class LandingController < ApplicationController
  def index
    redirect_to home_path if user_signed_in?
  end
end
