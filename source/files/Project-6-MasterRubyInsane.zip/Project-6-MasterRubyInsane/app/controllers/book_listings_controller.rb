# @author Oliver Shen 7/19/2025
class BookListingsController < ApplicationController
  before_action :set_book_listing, only: %i[ show edit update destroy ]

  # GET /book_listings
  def index
    @book_listings = BookListing.all
  end

  # GET /book_listings/1
  def show
  end

  # GET /book_listings/new
  def new
    @book_listing = BookListing.new
  end

  # GET /book_listings/1/edit
  def edit
  end

  # POST /book_listings
  def create
    @book_listing = current_user.book_listings.build(book_listing_params.except(:user_id))

    if @book_listing.save
      redirect_to @book_listing, notice: "Book listing was successfully listed."
    else
      render :new, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /book_listings/1
  def update
    respond_to do |format|
      if @book_listing.update(book_listing_params)
        format.html { redirect_to @book_listing, notice: "Book listing was successfully updated." }
        format.json { render :show, status: :ok, location: @book_listing }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @book_listing.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /book_listings/1
  def destroy
    @book_listing.destroy!

    respond_to do |format|
      format.html { redirect_to book_listings_path, status: :see_other, notice: "Book listing was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_book_listing
      @book_listing = BookListing.find(params.expect(:id))
    end

    # Only allow a list of trusted parameters through.
    def book_listing_params
      params.require(:book_listing).permit(:isbn, :listing_price, :condition, :user_id, :picture)
    end
end
