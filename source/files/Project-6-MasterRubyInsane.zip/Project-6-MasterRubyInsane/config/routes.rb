Rails.application.routes.draw do
  get "landing/index"
  get "book_purchases/new"
  get "wishlists/new"
  get "users/index"
  get "home/index"
  devise_for :users
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Render dynamic PWA files from app/views/pwa/* (remember to link manifest in application.html.erb)
  # get "manifest" => "rails/pwa#manifest", as: :pwa_manifest
  # get "service-worker" => "rails/pwa#service_worker", as: :pwa_service_worker

  # Defines the root path route ("/")
  # root "posts#index"

  # @author Anshuman Ranjan
  #root to: "home#index"
  #get "/users", to: "users#index"
  #####

   # author Yunfeng Wang
    root to: "landing#index"
    get "/home", to: "home#index"
    get "/landing", to: "landing#index"

  # author Yunfeng Wang
  #Root path
  #root 'book_information#index'
  # Book info routes
  resources :book_information
  get "books", to: "book_information#index", as: "books_home"
  
  # @author Oliver Shen 7/19/2025
  # Book Listings route
  resources :book_listings

  # Author Sam Cubberly
  resources :book_purchases
  resources :wishlists

end
