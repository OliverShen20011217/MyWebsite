config/master.key = 8371d36d4bae19004e901cb32dcbd509
# Project-6-MasterRubyInsane

# Description
Buckeye Book Bazaar, a web application that allows OSU students to buy and sell used books.  
  
# Managers
Overall Project Manager:  Anshuman Ranjan  
Meeting Manager: Oliver Shen  
Other team members: Yunfeng Wang, Sam Cubberly  
  
# Use Cases
- Case 1: CreateAccount/Login
    - Actor: Book Buyer/Seller
    - Stakeholder: Book Buyer/Seller
    - Preconditions: Account Doesn’t Exist/Account Exists
    - Triggers: Route from landing page?
    - Flow:
        - Login: Ask user for username and password
        - Create Account: Ask user for Personal Details + username and password
        - Alternative Flow: Forgot Password, Incorrect Password
- Case 2: Landing Page
    - Actor - Buyers and Sellers / Students
    - Stakeholder - Buyers / sellers
    - Preconditions - Just signed in / created account
    - Triggers - Route from Login page
    - Flow: Has search bar, wishlist, personal book listings, chats
- Case 3: Search Bar
    - Actor - Buyer
    - Stakeholder - Buyer / Seller
    - Preconditions - Someone has an idea for a book title, identifier, or maybe author
    - Triggers - Route from log in / on landing page, or route from book browsing already.
    - Flow - Type book attribute into search bar. Book Browsing will show up.
- Case 4: Book Browsing
    - Actor: Buyers
    - Stakeholder: Buyers / Sellers
    - Preconditions: The book attributes are spelled correctly
    - Triggers: Routed from hitting enter on the search bar
    - Alternative trigger: Someone adds a filter, book browsing reloads
    - Alternative Trigger: Viewing general listings
    - Flow: Hit enter on search bar. Book images, as well as book information, price, seller information shows up in a list.
- Case 5: Filter 
    - Actor - Buyer
    - Stakeholder - Buyer
    - Preconditions - User know what they want to filter on
    - Triggers - On the book browsing page, and click on the filter button.
    - Flow
        - User clicks on filter button.
        - Select a filter or sorting option (below $15, or sort from a-z … )
        - Submit Filter Options
        - Book Browsing loads
- Case 6: Add to Wishlist
    - Actor: Book Buyer
    - Stakeholder: Book Seller
    - Preconditions:Book exist/not exists 
    - Triggers: have book listing browsed
    - Flow
        - Basic Flow: click button, have the book added to buyer’s wishlist
        - Alternative Path: book not exist, create a record to the database (ISBN)
- Case 7: Create Book Listing
    - Actor: Book seller
    - Stakeholder: Book Buyer
    - Preconditions: The user must have an account and be logged in 
    - Triggers: The user clicks the “Create Book Listing” button
    - Flow
    - Basic Flow
        - The user fills out the book listing form
            - ListingID
            - ISBN
            - Listing Price
            - Condition
            - picture of the book
        - The system check for completeness
        - If valid, displayed the listing in the Home page
    - Alternative Path
        - If the ISBN format is invalid or already exists, the system displays an error message.
        - If required fields are missing, the system prompts the user to complete them.


# Meeting Reports
**Meeting 1: 7/15**  
1. Members Present:  
    - Sam Cubberly, Anshuman Ranjan, Oliver Shen, Yunfeng Wang  
2. Goals:   
    - Sam Cubberly: Provide the idea of data tables to enable everyone to clearly understand which data we need and how to categorize them.  
    - Oliver Shen: Supplement the content that we might have missed in user cases.  
    - Yunfeng Wang: Have a clear understanding and ideas about Views to ensure that everyone's tasks are evenly distributed.  
    - Anshuman Ranjan: Share the ideas of use cases to help everyone clearly understand how to write processes correctly.   
3. Meeting Notes:    
    - Five data tables — User Login, Book Information, User Information, Book Purchase, Wishlist.  
    - The four members wrote eight user cases, shared the ideas together.  
    - Nine corresponding views were identified.  
    - Each person was assigned the task of creating the tables are generating default 7 RAILS routes for sprint 1.  
  
**Meeting 2: 7/20 Stand Up**  
1. Members Present:    
    - Sam Cubberly, Anshuman Ranjan, Oliver Shen, Yunfeng Wang  
2. Goals:  
    - We wanted to see how everyone implemented the code, and then make plans to change code.  
3. Meeting Notes:  
    - Currently, the website has multiple basic views, providing access to modify the overall model of the website.  
    - Everyone has achieved this goal and, in the process, has also paved the way for faster development (using the framework).  
    - The website does work very well. It just needs to be connected together and refined with a clear layout.  
  
**Meeting 3: 7/20**  
1. Members Present:    
    - Sam Cubberly, Anshuman Ranjan, Oliver Shen, Yunfeng Wang  
2. Goals:    
    - Sam Cubberly: Goals to share thoughts on all page functions and logic, especially the wishlist page.  
    - Oliver Shen: Goals to list all the view pages and everyone can pick one or two to deal with.  
    - Yunfeng Wang: Goals to share the content related to User Infomation and discuss whether a dedicated page is needed for it.  
    - Anshuman Ranjan: Provide the logic of layout and landing page to make everyone clear about what should be included in the layout.  
3. Meeting Notes:  
    - Based on the views we discussed for the first time, we updated and expanded the important pages.  
    - We have currently designed Landing Page, layout.erb, my profile page, book listing page and my wishlist page. transaction history page and add new listing page.  
    - We ensured that everyone understood the logic, layout and interrelationships of each page.  
    - Each member was assigned 1 to 2 pages as tasks for sprint2.  
  
# Contributions
Anshuman Ranjan:
(07/19/25)
    - "rails new ."  
    - "bundle install gem 'devise'" -> "rails generate devise:install"  
    - "rails generate controller home index" -> routes.rb: "root to: "home#index"  
    - "rails generate devise User"  
    - "rails generate migration AddCustomFieldsToUsers first_name:string last_name:string osu_id:string phone:string address:string"  
    - "rails generate migration RemoveOsuEmailFromUsers osu_email:string"  
    - "rails generate devise:views"  
    - "rails generate controller users index"  
    - Ruby code in app/views/users/index.html.erb  
 



# Sprint #1
Due 7/17/25  
Create the tables are generate default 7 RAILS routes  
User Login + User Information- Anshuman Ranjan  
Book Information               - Yunfeng Wang  
Book Purchase + Wishlist   - Sam Cubberly  
Book Listing		          - Oliver Shen
   
# Sprint #2
Due 7/22/25  
Landing Page, Add new Listing page - Yunfeng Wang  
Layout.erb, My Profile Page - Anshuman Ranjan  
Book Listing Page, Transaction History Page - Oliver Shen  
My Wishlist Page, Wishlish button in Book Listing Page - Sam Cubberly  

# Continue sprints ...
