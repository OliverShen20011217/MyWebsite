# @author Oliver Shen 7/19/2025
require "test_helper"

class BookListingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
