require "test_helper"

class BookInformationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
