# @author Oliver Shen 7/19/2025
require "test_helper"

class BookListingsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @book_listing = book_listings(:one)
  end

  test "should get index" do
    get book_listings_url
    assert_response :success
  end

  test "should get new" do
    get new_book_listing_url
    assert_response :success
  end

  test "should create book_listing" do
    assert_difference("BookListing.count") do
      post book_listings_url, params: { book_listing: { condition: @book_listing.condition, isbn: @book_listing.isbn, listing_price: @book_listing.listing_price, user_id: @book_listing.user_id } }
    end

    assert_redirected_to book_listing_url(BookListing.last)
  end

  test "should show book_listing" do
    get book_listing_url(@book_listing)
    assert_response :success
  end

  test "should get edit" do
    get edit_book_listing_url(@book_listing)
    assert_response :success
  end

  test "should update book_listing" do
    patch book_listing_url(@book_listing), params: { book_listing: { condition: @book_listing.condition, isbn: @book_listing.isbn, listing_price: @book_listing.listing_price, user_id: @book_listing.user_id } }
    assert_redirected_to book_listing_url(@book_listing)
  end

  test "should destroy book_listing" do
    assert_difference("BookListing.count", -1) do
      delete book_listing_url(@book_listing)
    end

    assert_redirected_to book_listings_url
  end
end
