require "test_helper"

class BookPurchasesControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get book_purchases_new_url
    assert_response :success
  end
end
