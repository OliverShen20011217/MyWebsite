# @author Oliver Shen 7/19/2025
require "application_system_test_case"

class BookListingsTest < ApplicationSystemTestCase
  setup do
    @book_listing = book_listings(:one)
  end

  test "visiting the index" do
    visit book_listings_url
    assert_selector "h1", text: "Book listings"
  end

  test "should create book listing" do
    visit book_listings_url
    click_on "New book listing"

    fill_in "Condition", with: @book_listing.condition
    fill_in "Isbn", with: @book_listing.isbn
    fill_in "Listing price", with: @book_listing.listing_price
    fill_in "User", with: @book_listing.user_id
    click_on "Create Book listing"

    assert_text "Book listing was successfully created"
    click_on "Back"
  end

  test "should update Book listing" do
    visit book_listing_url(@book_listing)
    click_on "Edit this book listing", match: :first

    fill_in "Condition", with: @book_listing.condition
    fill_in "Isbn", with: @book_listing.isbn
    fill_in "Listing price", with: @book_listing.listing_price
    fill_in "User", with: @book_listing.user_id
    click_on "Update Book listing"

    assert_text "Book listing was successfully updated"
    click_on "Back"
  end

  test "should destroy Book listing" do
    visit book_listing_url(@book_listing)
    click_on "Destroy this book listing", match: :first

    assert_text "Book listing was successfully destroyed"
  end
end
