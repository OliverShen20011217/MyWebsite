class AddSellerIdToBookPurchase < ActiveRecord::Migration[8.0]
  def change
    add_column :book_purchases, :seller_id, :integer
  end
end
