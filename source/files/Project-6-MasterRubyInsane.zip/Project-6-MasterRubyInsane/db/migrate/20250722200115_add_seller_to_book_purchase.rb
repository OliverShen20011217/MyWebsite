class AddSellerToBookPurchase < ActiveRecord::Migration[8.0]
  def change
    add_column :book_purchases, :seller, :string
  end
end
