class RemoveBuyerFromBookPurchases < ActiveRecord::Migration[8.0]
  def change
    remove_column :book_purchases, :buyer, :string
  end
end
