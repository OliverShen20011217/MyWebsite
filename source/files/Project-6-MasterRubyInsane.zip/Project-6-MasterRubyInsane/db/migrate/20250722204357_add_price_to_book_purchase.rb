class AddPriceToBookPurchase < ActiveRecord::Migration[8.0]
  def change
    add_column :book_purchases, :price, :integer
  end
end
