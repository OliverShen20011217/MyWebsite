class RemoveIsbnFromBookPurchases < ActiveRecord::Migration[8.0]
  def change
    remove_column :book_purchases, :isbn, :string
  end
end
