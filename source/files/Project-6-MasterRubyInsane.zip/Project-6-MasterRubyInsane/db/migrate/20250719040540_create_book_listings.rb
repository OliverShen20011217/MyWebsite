# @author Oliver Shen 7/19/2025

# frozen_string_literal: true

# Migration to create the book_listings table.
# This table stores user-submitted book listings for sale, including ISBN, price, condition,
# and a reference to the user who posted the listing.

class CreateBookListings < ActiveRecord::Migration[8.0]
  def change
    create_table :book_listings do |t|
      t.string :isbn
      t.decimal :listing_price
      t.string :condition
      t.string :picture
      t.references :user, null: false, foreign_key: true

      t.timestamps
    end
  end
end
