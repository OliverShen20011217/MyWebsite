class RemoveSellerFromBookPurchases < ActiveRecord::Migration[8.0]
  def change
    remove_column :book_purchases, :seller, :string
  end
end
