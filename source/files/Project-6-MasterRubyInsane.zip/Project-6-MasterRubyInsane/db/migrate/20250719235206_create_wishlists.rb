class CreateWishlists < ActiveRecord::Migration[8.0]
  def change
    create_table :wishlists do |t|
      t.string :user
      t.integer :isbn

      t.timestamps
    end
  end
end
