class CreateBookInformations < ActiveRecord::Migration[8.0]
  def change
    create_table :book_informations do |t|
      t.string :isbn
      t.string :title
      t.string :author
      t.string :genre
      t.text :description
      t.string :keywords
      t.string :categories

      t.timestamps
    end
  end
end
