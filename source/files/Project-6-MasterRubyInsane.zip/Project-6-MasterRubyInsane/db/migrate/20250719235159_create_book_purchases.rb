class CreateBookPurchases < ActiveRecord::Migration[8.0]
  def change
    create_table :book_purchases do |t|
      t.integer :listingid
      t.string :pickupLocation
      t.string :buyer

      t.timestamps
    end
  end
end
