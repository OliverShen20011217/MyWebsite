class AddBuyerIdToBookPurchase < ActiveRecord::Migration[8.0]
  def change
    add_column :book_purchases, :buyer_id, :integer
  end
end
