class ChangeIsbnToBeStringInWishlists < ActiveRecord::Migration[8.0]
  def up
	change_column :wishlists, :isbn, :string
  end
  def down
	change_column :wishlists, :isbn, :integer
  end
end
