
#dealer.rb
# @author Sam Cubberly
# @created 5/19/2025
# @description Module to decide if the rules are adhered to
# @methods is_player_set_valid, identify_set_on_board

# @edited Oliver Shen 5/28/25
# @notes: removed single-line comments and replaced for loops with Integer loops

# @edited Sam Cubberly 5/29/25 -  re-wrote methods to use more advanced ruby techniques

# @edited Sam Cubberly 5/30/25 - converted to a module, removed initialize

# @edited Sam Cubberly 6/1/25 - Added the player_input method using Timeout
require "./card.rb"
require 'timeout'

module  Dealer

	# @created Sam Cubberly 5/29/25
	# Checks 3 attributes for 1. All Equal or 2. All Different values
	# @param vals [Array<Integer>] Array of 3 integer values
	# @return [TrueClass] if 1. All equal or All Different valus
	#	  else [FalseClass]
	def compare_attributes vals; vals[0] == vals[1] ? vals[0] == vals[2] : vals[0] != vals[2] && vals[1] != vals[2]; end 

	# @edited Sam Cubberly 5/21/25 - incorporated card class
	# @edited Sam Cubberly 5/29/25 - incorporated compare_attributes method and rewrote logic
	# Checks 3 cards to see if it is a set
	# @param cards [Array<Card>] containing 3 card objects
	# @returns [TrueClass] if set is valid
	# 	else [FalseClass]
	def is_player_set_valid cards 
		card1_attrs, card2_attrs, card3_attrs = cards.map{|card| card.to_array }
		4.times { |i| return false unless compare_attributes [card1_attrs[i], card2_attrs[i], card3_attrs[i] ] }
		true
	end

	# @created Sam Cubberly 5/20/25
	# @edited Sam Cubberly 5/29/25
	# @param board [Array<Card>]
	# @returns if @board contains valid set - returns array of indexes of set
	#	   else returns [-1]
	def identify_set_on_board board
		board.each_index {|i|
			 board.each_index {|j| 
				board.each_index {|k| 
					if i != j && j!= k && i != k
						return [i,j,k] if is_player_set_valid [board[i], board[j], board[k]]
					end
				 }
		 	}
		 }
		[-1]
	end

	# Created by Yunfeng Wang 6/1/2025
	# @edited Anshuman Ranjan 6/1/25 added a missing "end" tag
	# Displays the current leaderboard with player scores in descending order.
	# @param player_hash [Hash{Integer => Player}]
	#   A hash where the key is the player number (Integer) and the value is a Player object.
	# @return [nil]
	# The leaderboard is sorted in descending order of player scores.
	def display_leaderboard(player_hash)
  		sorted = player_hash.sort_by { |pair| -pair[1].score }
  		puts "\nLeaderboard:"
  		sorted.each do |player_num, player|
    			puts "Player #{player_num}: #{player.score} point(s)"
		end
  	end

	# @created Sam Cubberly 6/1/25
	# @edited Anshuman Ranjan 6/1/25 changed name of method and changed return type to string.
        # Limits time to 5 seconds for the user to input a string
	# @returns if within time limit: [String] of user input
	#          else: prints error message and returns -1 [Integer]
	def timed_player_input
		begin
			puts "\nPick 3 cards '0 1 2' OR ask for 'hint' OR end the game 'quit':"
			Timeout.timeout(5) {gets.strip.downcase}
		rescue Timeout::Error #exception class thrown by Timeout
			puts "Took Too Long"
			""
		end
		
	end
end

