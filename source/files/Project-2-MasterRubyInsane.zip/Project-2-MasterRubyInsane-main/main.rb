#main.rb
# @author Anshuman Ranjan and Yunfeng Wang
# @created 5/20/2025
# @description Script sets up the game loop, handles user interaction, validates input, evaluates sets,
#               tracks score, and determines end-of-game conditions.
 
# @edited Oliver Shen 5/20/2025
# @notes: Created show_hint
 
# @edited Anshuman Ranjan 5/29/2025
# @notes: Rewrote ALL the methods defined in this file
#         did not touch the loop script

# @edited Sam Cubberly 5/30/2025
# @notes: Changed Dealer class to Dealer module, adjusted methods accordingly

# @edited Anshuman Ranjan 6/1/2025
# @notes: Created multiplayer feature and supporting classes for different modes

# @edited Sam Cubberly 6/1/2025
# @notes: Anshuman's connection failed, helped transcribe his latest work onto the document
# @notes: Debugged Anshuman's code

require_relative 'board'
require_relative 'deck'
require_relative 'player'
require_relative 'dealer'

#@author Anshuman Ranjan

# Print to console: Welcome player and explain rules
def display_welcome_message
  puts "Welcome to the set_game."
  puts "Rules: Select 3 cards by number that form a valid set to gain a point."
  puts "Invalid sets incur -1 point."
  puts "Type 'hint' at any time for a suggestion (costs -0.5 points)."
  puts "Game ends when the deck is out of cards or there is no more sets remain."
  puts "Good luck!"
end

#@author Anshuman Ranjan
#Edit Yunfeng Wang 
#Update show_hint to check when hint result is -1, print no sets available message.
#Edit Sam Cubberly 5/30 removed dealer parameter, function calls through module

# Provides a hint by finding any valid set on the board
# deducts 0.5 points, and then displays the updated score.
# @params board [Board], player [Player]
def show_hint(board, player)
   set_on_board = identify_set_on_board board.cards_on_board
  if set_on_board == [-1]
    puts "No sets available right now."
  else
    puts "Hint: try cards #{set_on_board.join(', ')} (-0.5 points)"
  end

  player.score -= 0.5
  puts "Current score: #{player.score}"
end

# @author Anshuman Ranjan
# @edit Sam Cubberly 5/30 removed dealer parameter

# Reports if 1 of any 2 conditions have been met to end the game.
#   Condition 1: The deck has no more cards to draw
#   Condition 2: The dealer cannot find any possible sets on the board
# @params deck [Deck], board [Board]
def game_over?(deck, board)
  deck.deck.empty? || identify_set_on_board(board.cards_on_board) == [-1]
end

#@author Anshuman Ranjan

# Print to console: Report game over, report the final score,
#                   and tell which player (if any) won the game.
# @params players <Hash[Player] the list of players in the game
def display_final_result(players)
  winner_name = "Nobody"
  winner_score = -1
  puts "\nGAME OVER"
  puts "Final Score: "
  display_leaderboard(players)
  players.each do |name_str, player_obj|
    if player_obj.score > winner_score
	 winner_name, winner_score = player_obj.name, player_obj.score
    end
  end
  puts "#{winner_name} won the game!"
end


#@author Anshuman Ranjan

# Asks user to enter 3 numbers (from the board) and
# parses the input into an array of integers, returns [-1] if invalid input
# (non-numeric or out-of-bounds)
# @params max_index: <Integer> containing upper bounds of player input
# @return [Array<Integer>] containing list of 3 indices or -1
def get_player_input max_index
  puts "\nSelect 3 cards by their number, separated by newlines (0 - #{max_index}):"
  input = 3.times.map { gets.chomp }

  indices = input.map(&:to_i)
  indices = [-1] if indices.any? { |i| i < 0 || i > max_index }
  indices
end


#@author Anshuman Ranjan : Implmented method, case-when block, Code 0, 1, 2
#@contributor Yunfeng Wang : provided conditions for Code -1, -2, -3

# Parses user input to report if value is "hint", "quit", 
# "<int> <int> <int>", or some incorrect value
# @params user_input: <String> the ASCII value the user inputs
# @return <Integer> where [int] < 0 if invalid input
#                         [int] = 0 to end game
#                         [int] > 0 to continue game
def get_user_command user_input
  input_array = user_input.split
  case
  when user_input == "quit"
    #Code 0 : end the game
    puts "--Ending the game--"
    0
  when user_input == "hint"
    #Code 2 : provide a hint
    puts "--Providing a hint--"
    2
  when user_input == ""
    #Code -4 : Ran out of time
    puts("Error: Ran out of time")
    -4
  when input_array.length != 3
    #Code -1 : incorrect number of values
    puts "Error: Incorrect number of values entered"
    -1
  when !input_array.all? { |arr_element| arr_element.to_i.to_s == arr_element }
    #Code -2 : incorrect value type
    puts "Error: Found a non-Integer value"
    -2
  when !input_array.all? { |arr_element| arr_element.to_i >= 0 && arr_element.to_i < 12 }
    #Code -3 : incorrect value range (Board only contains 12 elements)
    puts "Error: Index out-of-range"
    -3
  else
    #Code 1 : Correct values entered
    puts "You selected the cards : #{input_array.join(' ')}"
    1
  end
end

#@author Anshuman Ranjan

# Parses user input for an integer > 0 and creates a hash with
# that many <Player> instances for the game
# @return <Hash[<String>, <Player>]> where
#         <String> is the player's name
#         <Player(name)> is the instantiated Player object
def create_players
  #Repeatedly ask for valid number of players
  begin
      puts "\nEnter the number of players in the game (>= 1): "
      num_players = gets.strip.downcase.to_i
      puts "Invalid Value" if num_players < 1
  end while num_players < 1
  #Create a hash that holds all the players
  players = {}
  num_players.times do |i|
    puts "Enter name for Player #{i+1}: "
    name = gets.chomp
    players[name] = Player.new(name)
  end
  players
end

include Dealer

#@author Anshuman Ranjan
#@contributor Yunfeng Wang : all the code in the Case-When statement for command_code === 1

#Instantiates all nessesary classes and runs the game loop
def main
  #Dealer module containing methods to handle game mechanics
  #include Dealer
  # deck = shuffled full deck
  deck = Deck.new
  # board = empty array that represents the cards on the board.
  board = Board.new
  # player = new player with a score of 0
  players = create_players

  # Put 12 cards on the board
  board.cards_on_board = deck.random_draw(12)

  # game start
  display_welcome_message

  loop do
    #Display the updated game board
    puts "\nCurrent Board:"
    board.display

    begin
      puts "\nEnter player name:  "
      player_name = gets.chomp
      puts "Invalid Player Name" if !players.key?(player_name)
    end while !players.key?(player_name)
    player = players[player_name]
    puts "#{player.name}: You have 5 seconds to answer"

    user_input = timed_player_input()
    command_code = get_user_command(user_input)
      
    case command_code
    when 0 #End the game loop
      break 
    when 2  #Provide a hint
      show_hint(board, player)
    when 3 #Display Leaderboard
      display_leaderboard(players)
    when 1 #Only runs when provided 3 ints between 0-12
      # Check validity of set 
      #Create <Array[Integer]> containing index of cards to select
      indices = user_input.split.map { |element| element.to_i }
      #Create <Array[Card]> containing selected cards
      selected_cards = indices.map { |i| board.cards_on_board[i] }
      if is_player_set_valid(selected_cards) && (indices[0] != indices[1] && indices[1] != indices[2] && indices[2] != indices[0])
        puts "Valid Set! +1 point"
        puts "Cards removed:"
        indices.each { |i| puts "- Card #{i}: #{board.cards_on_board[i].to_s}" }
        player.score += 1
        deck.deck.size >= 3 ? board.replace_cards(indices, deck) : puts("Insufficient cards in deck to replace")
      else
        puts( "Invalid Set. -1 point" )
        player.score -= 1
      end
      puts( "Current score: #{player.score}" )
      puts( "Cards remaining in deck: #{deck.deck.size}" )
    else
	next #restart the loop
    end
	#end game if deck out of cards and board has no valid sets
    break if game_over?(deck, board)
  end
  # Final score and result display
  display_final_result(players)        
end

# @Author Anshuman Ranjan
if __FILE__ == $0
  main
end
