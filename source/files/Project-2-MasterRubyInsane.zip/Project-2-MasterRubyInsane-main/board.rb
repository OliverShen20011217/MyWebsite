#board.rb
# @author Yunfeng Wang
# @created 5/19/2025
# @description Handles the current state of cards shown on board for the game of Set.
# @methods initialize, display, discard_cards[Array<Integer>], replace_cards[]
# 
# @edited Anshuman Ranjan 5/28/2025
# @notes: Removed attr_accessor, updated documentation format
require "./card.rb"
require "./deck.rb"

class Board
  #Edited - Yunfeng Wang 5/29 
  attr_accessor :cards_on_board
  
  # initializes the board with an empty set of cards
  # @return [Board] new board instance with empty list of cards[Array<Card>]
  def initialize
    @cards_on_board = []
  end

  # @edited Sam Cubberly 5/21/2025
  # @notes: returned an index along with it, as well as incorporated the card class
  
  # prints each card currently on the board to the console.
  # @uses Card.to_s
  # @return index : <Integer> number of cards on board
  #Edit - Sam Cubberly 5/28
  #	 Reduced code to 1 line
  def display
    @cards_on_board.each_index { |i| puts "Card #{i.to_s}: " + @cards_on_board[i].to_s }
  end

  #Created Yunfeng Wang 5/19
  # removes cards from the board at the given indices.
  # @param indices : [Array<Integer>] indices of the cards to remove
  # @return [void]
  #Edit - Sam Cubberly - 5/28 - Made code terse
  def discard_cards(indices)
    indices.sort.reverse.each { |i| @cards_on_board.delete_at(i) }
  end

  #Created Yunfeng Wang 5/19
  # replaces cards at the given indices with new ones from the deck.
  # if the deck is empty, removes the card instead of replacing it.
  # @param indices : [Array<Integer>] indices of cards to replace
  # @param deck : [Deck] the deck to draw new cards from
  # @uses Deck.deck
  # @uses Deck.random_draw
  # @return [void]
  #Edit - Terse Code
  def replace_cards(indices, deck)
    indices.each { |i| deck.deck.any? ? @cards_on_board[i] = deck.random_draw(1).first : @cards_on_board.delete_at(i) }
  end
end

