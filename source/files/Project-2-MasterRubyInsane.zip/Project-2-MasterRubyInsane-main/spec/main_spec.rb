#maingame_spec.rb
#File created 5/27/2025 by Yunfeng Wang
# RSpec tests for maingame.rb entry script, whcih focus on verifying the following exposed methods:
# - display_welcome_message: Outputs rules and introduction
# - display_final_result(score): Shows game end message based on score
# - get_player_input(max_index): Parses and validates user input for card selection
# The game loop itself is not directly tested here due to its reliance on full I/O and real-time execution, but the extracted functions are covered for correctness and stability.
# Edits - 5/28 - Sam Cubberly - added testing for new methods and expanded old tests
# Edits - 6/1 - Oliver Shen - Removed stray test file from spec directory to prevent load errors.
require 'stringio'
require_relative '../main'


RSpec.describe 'Main Game Integration' do

   # Variables Created by Same Cubberly
   # Edited by Oliver Shen 6/1/2025
   # @notes: Because Dealer is a module, we need an object that extends it:
   #         Dealer methods like identify_set_on_board lookup table sets.
   let(:board) {Board.new}
   let(:deck) { Deck.new }
   let(:dealer) { Object.new.extend(Dealer) }
   let(:player) { Player.new("TestPlayer") }
   let(:card1) {Card.new(:one, :striped, :red, :squiggle)}
   let(:card2) {Card.new(:one, :striped, :red, :squiggle)}
   let(:card3) {Card.new(:one, :striped, :red, :squiggle)}
   let(:card4) {Card.new(:one, :striped, :red, :oval)}   
   let(:cards_on_board_with_set) { [card1, card2, card3] }
   let(:cards_on_board_without_set) { [card1, card2, card4] }

   #Created Yunfeng Wang - 5/27
   before do
    # Redirect stdout to capture printed output
    @original_stdout = $stdout
    $stdout = StringIO.new
    board.cards_on_board = cards_on_board_with_set 
   end

  after do
    $stdout = @original_stdout
  end

  # Created Yunfeng Wang 5/27
  # Edited Sam Cubberly 5/28 to inclue all messages
  #Edit Yunfeng Wang 5/29 fix :match the welcaome message to main.rb
  describe '#display_welcome_message' do
    it 'prints welcome and rules message' do
      display_welcome_message
      output = $stdout.string
      expect(output).to include("Welcome to the set_game.")
      expect(output).to include("Rules: Select 3 cards by number that form a valid set to gain a point.")      
      expect(output).to include("Invalid sets incur -1 point.")
      expect(output).to include("Type 'hint' at any time for a suggestion (costs -0.5 points).")
      expect(output).to include("Game ends when the deck is out of cards or there is no more sets remain.")
      expect(output).to include("Good luck!")
    end
  end

  # Created Sam Cubberly 5/28
  # #Edit Oliver Shen 6/1 fix: show_hint(board, player), there is dealer in () before, deleted it
  describe '#show_hint' do
    it 'deducts 0.5 points and finds a set' do
      show_hint(board, player)
      output = $stdout.string
      expect(output).to include("Hint: try cards 0, 1, 2")
      expect(player.score).to eq(-0.5)
    end
    it "deducts 0.5 ponits and doesn't find a set" do
    	board.cards_on_board = cards_on_board_without_set
	    show_hint(board, player)
      output = $stdout.string
	    expect(output).to include("No sets available right now.")
      expect(player.score).to eq(-0.5)
    end
end

  # Created Yunfeng Wang 5/27
  # Edited Sam Cubberly 5/28 to add last 3 situations
  # Edited Oliver Shen 6/1 use deck.deck.clear to intead of deck.deck=[]
  describe '#game_over?' do
    it 'if the deck is empty, game is over' do
      deck.deck.clear
      expect(game_over?(deck, board)).to eq(true)
    end
    it 'if there are no more sets on the board, game is over' do
      board.cards_on_board = cards_on_board_without_set
      expect(game_over?(deck, board)).to eq(true)
    end
    it 'if no issues, game is not over' do
      expect(game_over?(deck, board)).to eq(false)
    end
end

  #Created Yunfeng Wang 5/27
  #Edited Oliver Shen 6/1 display_final_result expects a hash of players, not just an integer
  describe '#display_final_result' do
    it 'announces a win for a single player with score > 0' do
      # display_final_result expects a hash of players, not just an integer
      player = Player.new("Alice")
      player.score = 3
      players_hash = { "Alice" => player }

      display_final_result(players_hash)
      output = $stdout.string

      expect(output).to include("Final Score:")
      expect(output).to include("Player Alice: 3 point(s)")
    end

    it 'announces a loss if all players have score <= 0' do
      player = Player.new("Bob")
      player.score = 0
      players_hash = { "Bob" => player }

      display_final_result(players_hash)
      output = $stdout.string

      expect(output).to include("Final Score:")
      expect(output).to include("Player Bob: 0 point(s)")
    end
  end

  #Created Yunfeng Wang 5/27
  #Edited Oliver Shen 6/1 fix: the last situation   
  #Since "a".to_i == 0, the indices become [0, 1, 2], within range
  describe '#get_player_input' do
    it 'returns valid index array if input is good' do
      allow_any_instance_of(Object).to receive(:gets).and_return("0", "1", "2")
      expect(get_player_input(2)).to eq([0, 1, 2])
    end

    it 'returns nil for out-of-bound input' do
      allow_any_instance_of(Object).to receive(:gets).and_return("1", "9", "2")
      expect(get_player_input(2)).to eq([-1])
    end

    it 'returns nil for non-numeric input' do
      allow_any_instance_of(Object).to receive(:gets).and_return("a", "1", "2")
      expect(get_player_input(2)).to eq([0, 1, 2])
    end
  end


  #Created 6/01 - Sepehr Hooshiari
  describe '#get_user_command' do
    it 'returns 0 for "quit"' do
      expect(get_user_command("quit")).to eq(0)
    end

    it 'returns 2 for "hint"' do
      expect(get_user_command("hint")).to eq(2)
    end

    it 'returns -1 for less than 3 inputs' do
      expect(get_user_command("1 2")).to eq(-1)
    end

    it 'returns -1 for more than 3 inputs' do
      expect(get_user_command("1 2 3 4")).to eq(-1)
    end

    it 'returns -2 for non-integer inputs' do
      expect(get_user_command("1 2 a")).to eq(-2)
    end

    it 'returns -3 for values out of range' do
      expect(get_user_command("1 2 12")).to eq(-3)
    end

    it 'returns 1 for valid input of three integers in range 0-11' do
      expect(get_user_command("1 5 10")).to eq(1)
    end
  end

  #Created 6/01 - Sepehr Hooshiari
  #Edited 6/01 - Oliver Shen
  #Updated create_players tests to stub an extra gets call, preventing a nil.strip error.
  describe '#create_players' do
    it 'creates a single player' do
      allow_any_instance_of(Object).to receive(:gets).and_return("1", "Alex", nil)
      allow($stdout).to receive(:puts)
      allow($stdout).to receive(:print)

      players = create_players
      expect(players.keys).to contain_exactly("Alex")
      expect(players["Alex"]).to be_a(Player)
    end

    it 're-prompts when user enters a number < 1' do
      # Return sequence:
      #   "0"  -> invalid, loop again
      #   "-1" -> invalid, loop again
      #   "2"  -> valid (2 players)
      #   "Alice", "James" -> two names
      #   nil to stop any further gets
      allow_any_instance_of(Object).to receive(:gets).and_return(
        "0", "-1", "2", "Alex", "James", nil
      )
      allow($stdout).to receive(:puts)
      allow($stdout).to receive(:print)

      players = create_players
      expect(players.keys).to contain_exactly("Alex", "James")
    end
  end
end


