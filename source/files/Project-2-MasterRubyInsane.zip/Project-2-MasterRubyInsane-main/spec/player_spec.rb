#main_spec.rb
#File created 5/28/2025 by Yunfeng Wang
# RSpec tests for the Player class, which handles scoring based on set validity.
# - Initialization: verifies score and valid_score start at 0
# - select_set(cards): adjusts player score depending on whether selected cards form a valid set
# Mocking Strategy:
# - Uses double() to simulate Card objects with predefined to_array values
# - Injects Dealer mock object to isolate Player logic from actual set validation internals
# @edited Oliver Shen 6/1/2025
# @notes: Updated the Player specs to include name initialization, 
#         verify score remains unchanged for invalid card counts, 
#         and test score increment/decrement for valid and invalid sets.


require "./player.rb"
require 'rspec'

RSpec.describe Player do
  let(:player) { Player.new("TestPlayer") }

  let(:valid_cards) do
    [
      double('Card', to_array: [0, 0, 0, 0]), 
      double('Card', to_array: [1, 1, 1, 1]),
      double('Card', to_array: [2, 2, 2, 2])
    ]
  end

  let(:invalid_cards) do
    [
      double('Card', to_array: [0, 0, 0, 0]),
      double('Card', to_array: [0, 0, 0, 0]),
      double('Card', to_array: [0, 0, 0, 1])
    ]
  end

  describe '#initialize' do
    it 'sets the name attribute correctly' do
      expect(player.name).to eq("TestPlayer")
    end

    it 'initializes score to 0' do
      expect(player.score).to eq(0)
    end
  end

  describe '#select_set' do
    context 'when provided fewer or more than 3 cards' do
      it 'returns false and does not change the score' do
        result = player.select_set([valid_cards.first])
        expect(result).to eq(false)
        expect(player.score).to eq(0)

        four_cards = valid_cards + [valid_cards.first]
        result = player.select_set(four_cards)
        expect(result).to eq(false)
        expect(player.score).to eq(0)
      end
    end

    context 'when provided exactly 3 cards' do
      it 'increments score by 1 for a valid set' do
        player.select_set(valid_cards)
        expect(player.score).to eq(1)
      end

      it 'decrements score by 1 for an invalid set' do
        player.select_set(invalid_cards)
        expect(player.score).to eq(-1)
      end
    end
  end
end



