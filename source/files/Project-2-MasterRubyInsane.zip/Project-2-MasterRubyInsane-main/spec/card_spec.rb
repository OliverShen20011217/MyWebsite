# spec/card_spec.rb
# File created 5/28/25 by Sepehr Hooshiari
# @created Sepehr Hooshiari 5/20/2025 
# @edited Oliver Shen 5/30/2025
# @notes: 1. Renamed the to_string method to the standard to_s and updated the corresponding test to check #to_s.
#         2. Added new tests for #to_h to verify it returns a hash of all four attributes.
# RSpec testing for the Card class (card.rb)

require 'spec_helper'
require_relative '../card'

RSpec.describe Card do
  describe '#initialize' do
    it 'correctly assigns attributes' do
      card = Card.new(:one, :striped, :green, :oval)
      expect(card.number).to eq(:one)
      expect(card.shading).to eq(:striped)
      expect(card.colour).to eq(:green)
      expect(card.symbol).to eq(:oval)
    end
  end

  describe '#to_s' do
    it 'returns a readable string of attributes' do
      card = Card.new(:two, :solid, :purple, :squiggle)
      expect(card.to_s).to eq('two solid purple squiggle')
    end
  end

  describe '#to_array' do
    it 'converts attributes to corresponding indices' do
      card = Card.new(:three, :open, :red, :diamond)
      expect(card.to_array).to eq([2, 2, 0, 0])
    end

    it 'returns the correct indices for all mid-values' do
      card = Card.new(:two, :striped, :green, :oval)
      expect(card.to_array).to eq([1, 1, 1, 1])
    end
  end

    describe '#to_h' do
    it 'returns a hash with all attribute keys and values' do
      card = Card.new(:one, :solid, :red, :diamond)
      expect(card.to_h).to eq({
        number:  :one,
        shading: :solid,
        colour:  :red,
        symbol:  :diamond
      })
    end

    it 'returns different hashes for different cards' do
      card1 = Card.new(:one, :solid, :red, :diamond)
      card2 = Card.new(:one, :open, :red, :diamond)
      expect(card1.to_h).not_to eq(card2.to_h)
    end
  end
end
