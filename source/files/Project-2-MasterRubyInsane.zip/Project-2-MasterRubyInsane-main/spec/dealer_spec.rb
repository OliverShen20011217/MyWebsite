# spec/dealer_spec.rb
# File created 5/20/25 by Oliver Shen
# @created Oliver Shen 5/20/2025 
# @edited Oliver Shen 5/30/2025
# @Edit Yunfeng Wang 6/1/2025: test case for display_leaderboard
# @Edit Oliver Shen 6/1/2025: added test for timed_player_input' and Timeout

require 'spec_helper'
require_relative '../card'
require_relative '../dealer'

RSpec.describe Dealer do
  include Dealer

  describe '#compare_attributes' do
    it 'returns true when all three values are equal' do
      expect(compare_attributes([1, 1, 1])).to be true
    end

    it 'returns true when all three values are different' do
      expect(compare_attributes([0, 1, 2])).to be true
    end

    it 'returns false when neither all equal nor all different' do
      expect(compare_attributes([1, 1, 2])).to be false
      expect(compare_attributes([0, 2, 2])).to be false
    end
  end

  describe '#is_player_set_valid' do
    it 'returns true for a valid set (all attributes all-different)' do
      c1 = Card.new(:one,   :solid,   :red,    :diamond)
      c2 = Card.new(:two,   :striped, :green,  :oval)
      c3 = Card.new(:three, :open,    :purple, :squiggle)
      expect(is_player_set_valid([c1, c2, c3])).to be true
    end

    it 'returns false for an invalid set (mixed equal and different)' do
      c1 = Card.new(:one,   :solid,   :red,    :diamond)
      c2 = Card.new(:one,   :striped, :green,  :oval)
      c3 = Card.new(:two,   :open,    :purple, :squiggle)
      expect(is_player_set_valid([c1, c2, c3])).to be false
    end
  end

  describe '#identify_set_on_board' do
    it 'finds the first valid set indices when a set exists' do
      # valid set at positions 0,1,2
      c1 = Card.new(:one,   :solid,   :red,    :diamond)
      c2 = Card.new(:two,   :solid,   :red,    :diamond)
      c3 = Card.new(:three, :solid,   :red,    :diamond)
      board = [c1, c2, c3] + Array.new(9) { Card.new(:one, :solid, :green, :oval) }
      expect(identify_set_on_board(board)).to eq([0, 1, 2])
    end

    it 'returns [-1] when fewer than 3 cards on board' do
      board = [
        Card.new(:one, :solid, :red, :diamond),
        Card.new(:two, :striped, :green, :oval)
      ]
      expect(identify_set_on_board(board)).to eq([-1])
    end
  end

  #Edit Yunfeng Wang 6/1/2025
  #test case for display_leaderboard
  describe '#display_leaderboard' do
    let(:player1) { double('Player', score: 2) }
    let(:player2) { double('Player', score: 5) }
    let(:player3) { double('Player', score: 3) }

    let(:player_hash) do
      {
        1 => player1,
        2 => player2,
        3 => player3
      }
    end

    it 'displays message when player hash is empty' do
      expect {
        display_leaderboard({})
     }.to output("\nLeaderboard:\n").to_stdout
    end


    it 'prints leaderboard sorted by descending score' do
      expected_output = <<~OUTPUT

        Leaderboard:
        Player 2: 5 point(s)
        Player 3: 3 point(s)
        Player 1: 2 point(s)
      OUTPUT

    expect {
      display_leaderboard(player_hash)
    }.to output(expected_output).to_stdout
    end
  end
  describe '#timed_player_input' do
    context 'when user responds quickly' do
      it 'returns the downcased input string' do
        allow_any_instance_of(Kernel).to receive(:gets).and_return("Hello\n")
        result = timed_player_input
        expect(result).to eq('hello')
      end
    end

    context 'when Timeout::Error is raised' do
      it 'prints "Took Too Long" and returns an empty string' do
        allow(Timeout).to receive(:timeout).and_raise(Timeout::Error)
        expect {
          expect(timed_player_input).to eq('')
        }.to output(/Took Too Long/).to_stdout
      end
    end
  end
  
end
