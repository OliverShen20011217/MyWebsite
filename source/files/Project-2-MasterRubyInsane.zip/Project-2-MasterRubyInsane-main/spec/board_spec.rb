#spec/board_spec.rb
# @author Anshuman Ranjan
# @created 5/28/2025
# @description RSpec testing for the Board class (board.rb)
# @methods initialize, display, discard_cards[Array<Integer>], replace_cards[]

# @edited Sam Cubberly
# Corrected bugs and simplified code. Added test cases

require 'spec_helper'
require_relative '../board'
require_relative '../card'
require_relative '../deck'

RSpec.describe Board do
  let(:board) { Board.new }

# @author Anshuman Ranjan
  describe "#initialize" do
    it "starts with an empty cards_on_board array" do
      expect(board.cards_on_board).to eq([])
    end
  end

# @author Anshuman Ranjan
# @contributor Sam Cubberly
  describe "#display" do
    it "prints all cards with indices to the console" do
      c1 = Card.new(:one,   :solid,   :red,    :diamond)
      c2 = Card.new(:two,   :striped, :green,  :oval)
      c3 = Card.new(:three, :open,    :purple, :squiggle)

      board.cards_on_board = [c1, c2, c3]

      expected_output = "Card 0: one solid red diamond\nCard 1: two striped green oval\nCard 2: three open purple squiggle\n"
      expect { board.display }.to output(expected_output).to_stdout
    end

    it "works if 0 cards on board" do
      expected_output = []
      expect(board.display).to eq( expected_output )
    end

    it "works if 1 card is on the board" do
      c1 = Card.new(:one,   :solid,   :red,    :diamond)

      board.cards_on_board = [c1]

      expected_output = "Card 0: one solid red diamond\n"
      expect { board.display }.to output(expected_output).to_stdout
    end 

    it "works if 2 cards on the board" do
      c1 = Card.new(:one,   :solid,   :red,    :diamond)
      c2 = Card.new(:two,   :striped, :green,  :oval)

      board.cards_on_board = [c1, c2]

      expected_output = "Card 0: one solid red diamond\nCard 1: two striped green oval\n"
      expect { board.display }.to output(expected_output).to_stdout

    end

  end

# @author Anshuman Ranjan
# @contributor Sam Cubberly
  describe "#discard_cards" do
    it "removes the specified cards by index, basic test case" do
      c1 = Card.new(:one,   :solid,   :red,    :diamond)
      c2 = Card.new(:two,   :striped, :green,  :oval)
      c3 = Card.new(:three, :open,    :purple, :squiggle)

      board.cards_on_board = [c1, c2, c3]

      board.discard_cards([1])
      expect(board.cards_on_board).to eq([c1, c3])
    end
  end

# @author Anshuman Ranjan
# @contributor Sam Cubberly
  describe "#replace_cards" do
    it "replaces cards from the deck at the given indices" do
      c1 = Card.new(:one,   :solid,   :red,    :diamond)
      c2 = Card.new(:two,   :striped, :green,  :oval)
      c3 = Card.new(:three, :open,    :purple, :squiggle)
      c4 = Card.new(:four,  :solid,   :green,  :squiggle)

      deck_of_one = Deck.new

      board.cards_on_board = [c1, c2, c3]
      deck_of_one.deck = [c4]

      board.replace_cards([1], deck_of_one)
      expect(board.cards_on_board).to eq [c1, c4, c3]
    end

    it "attempts to replace cards using empty deck at given indices" do
      c1 = Card.new(:one,   :solid,   :red,    :diamond)
      c2 = Card.new(:two,   :striped, :green,  :oval)
      c3 = Card.new(:three, :open,    :purple, :squiggle)

      empty_deck = Deck.new

      board.cards_on_board = [c1, c2, c3]
      empty_deck.deck = []

      board.replace_cards([1], empty_deck)
      expect(board.cards_on_board).to eq [c1, c3]
    end
  end  
end
