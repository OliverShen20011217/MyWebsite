# spec/deck_spec.rb
# File created 5/28/25 by Sepehr Hooshiari
# @created Sepehr Hooshiari 5/20/2025 
# @edited Oliver Shen 5/30/2025
# @notes: test for the valid_deck attribute was deleted 
#         because validate_deck? The method has been removed. 
# RSpec testing for the Deck class (deck.rb)

require 'spec_helper'
require_relative '../deck'
require_relative '../card'

RSpec.describe Deck do
  let(:deck) { Deck.new }

  describe '#initialize' do
    it 'initializes a deck with 81 cards' do
      expect(deck.deck.size).to eq(81)
    end

    it 'contains only unique cards' do
      expect(deck.deck.uniq.size).to eq(81)
    end
  end

  describe '#random_draw' do
    it 'returns the correct number of cards drawn' do
      drawn = deck.random_draw(5)
      expect(drawn.size).to eq(5)
    end

    it 'removes the drawn cards from the deck' do
      original_size = deck.deck.size
      _drawn = deck.random_draw(10)
      expect(deck.deck.size).to eq(original_size - 10)
    end

    it 'returns Card objects' do
      drawn = deck.random_draw(3)
      expect(drawn).to all(be_a(Card))
    end
  end

  describe 'deck uniqueness and integrity' do
    it 'has no duplicate cards based on to_array' do
      unique_arrays = deck.deck.map(&:to_array).uniq
      expect(unique_arrays.size).to eq(81)
    end
  end
end
