#deck.rb
# @author Oliver Shen
# @created 5/20/2025
# @Manages a shuffled collection of 81 unique Card instances.
# @cards [Array<Card>] holds the current deck (shuffled)
# @methods initialize, random_draw(n), build_deck

# @edited Oliver Shen 5/20/2025
# @notes: update the build_deck function after the card class update
# @edited Oliver Shen 5/30/2025
# @notes: 1. Moved attribute arrays into the CardAttributes module and referenced them in build_full_deck.
#         2. Replaced result = result + […] with full_deck << Card.new(...) for cleaner array appends.
#         3. Removed the validate_deck? method and its @valid_deck flag to simplify.

# @edited Sam Cubberly 6/1/2025
# @notes: Converted deck getter to be an accessor

require_relative 'card'

class Deck
  # @deck       : Array<Card> – the shuffled deck of cards

  attr_accessor :deck
  
  # @Created Oliver Shen 5/20/2025
  # Build and shuffle all cards upon initialization.
  def initialize
    @deck = build_deck.shuffle
  end

  # @Created Oliver Shen 5/20/2025
  # Draw n cards from the top of the deck.
  # Returns an array of up to n Card objects.
  #
  # @param n [Integer] number of cards to draw
  # @return [Array<Card>] drawn cards
  # Created created 5/20/2025 by Oliver Shen
  def random_draw(n)
    deck.shift(n)
  end

  private

  # @Created Oliver Shen 5/20/2025
  # @Updated Oliver Shen 5/30/2025
  # @notes: Replaced result = result + […] with full_deck << Card.new(...) for cleaner array appends.
  # Generate the full set of 81 cards (Cartesian product of attributes),
  # using CardAttributes from the Card class.
  #
  # @return [Array<Card>] unshuffled deck
  def build_deck
    full_deck = []
    CardAttributes::NUMBERS.each do |num|
      CardAttributes::SHADINGS.each do |shade|
        CardAttributes::COLOURS.each do |col|
          CardAttributes::SYMBOLS.each do |sym|
            full_deck << Card.new(num, shade, col, sym)
          end
        end
      end
    end
    full_deck
  end

end




