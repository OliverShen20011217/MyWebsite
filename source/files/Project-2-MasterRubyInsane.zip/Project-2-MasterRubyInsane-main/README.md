# Project-2-MasterRubyInsane

# Description
**Summary:**   
This project is a full-featured Ruby implementation of the classic Set card game, designed with modularity, timed interaction, and multiplayer support, players take turns identifying valid sets on the board, with scoring, leaderboard tracking, and game-ending logic fully integrated. In the game, players look for combinations of three cards where each of four attributes (number, color, shading, symbol) are either all the same or all different. The game continues until no valid sets remain or the deck runs out.
  
**Structure:**   
*main.rb:* Controls the game loop, player interactions, turn logic, score updates, and game-ending conditions.  
*card.rb:* Defines the Card class and CardAttributes module. Each card has 4 attributes with 3 possible values each, generating 81 unique cards.  
*deck.rb:* Builds a full deck from all card combinations and supports random card drawing.  
*board.rb:* Manages the current set of visible cards on the board, and supports display, discard, and replace operations.  
*player.rb:* Stores player data like name and score, and validates sets using methods from the Dealer module.  
*dealer.rb:* A utility module responsible for validating sets, finding available sets on board, timed input, and display leaderboard.  
  
# Managers  

Overall Project Manager: Yunfeng Wang  
Meeting Manager: Sam Cubberly

# Use Cases
  **[Basic]** Start the Game.  
  a. The Game generates a full deck of 81 unique cards.  
  b. The Game generates a board.  
  c. The Game adds the Player[s].  
    
  **[Basic]** Deal the appropriate number of cards.   
  a. The Game randomly draws 12 cards and displays them on the Board.  
  b. The Dealer discards the used cards and replaces them with new ones.  
  
  **[Basic]** Verify the correctness of player-identified sets.  
  a. The Player chooses 3 cards from the Board.  
  b. The Dealer compares the 3 cards using their attributes (Color, Shape, Count, Shading).  
  c. The Dealer tries to find a similar attribute in all 3 cards.  
  d. If the Dealer succeeds, the Player gets a point, and the cards get discarded.  
  e. If the Dealer fails, the Player loses a point, and the cards are restored to the Board.  
  
  **[Basic]** Replace the identified cards with new ones.   
  a. The Dealer removes 3 cards from the Board.  
  b. The Dealer randomly draws 3 new cards from the deck (if ≥3 remain).  
  c. The Dealer adds the new cards to the Board (IF POSSIBLE), restoring it to 12 cards.  
  
  ***note: keeps_track will most likely be modifiable attributes of each class that will need multiple methods to increment/decrement/check.***  
    
  **[Basic]** Keep track of the score to identify a winner.  
  a. The Deck keeps track of the remaining cards in the Deck (81 >= x >= 0).  
  b. The Board keeps track of the cards left on the Board  
  c. Each Player keeps track of their score  
  d. The game ends when:  
    i. All sets have been found (Board and Deck are both empty)  
    ii. No more sets can be made from the cards on the Board, and no more new cards can be drawn (Only the Deck is empty)  
  e. When the game ends, the Player found with the most points wins  
  
  **[Optional]** Hint  
  a. Player asks for "Hint".  
  b. The Dealer searches the 12 cards on the Board and identifies a valid Set.  
  c. The Dealer highlights the Set.  
  
  **[Optional]** Timer mode  
  **[Optional]** Single vs. Computer players  
  **[Optional]** Statistics  
  **[Optional]** Modes or levels  
  **[Optional]** Change card skin  
  **[Optional]** Handle No Available Set (If there is not a single Set among these 12 cards)  
  
  
# Meeting Reports

**Meeting Notes**   
**-5/15 Meeting:**  
--All members present.   
--Allocated roles. Project Manager - Yunfeng Wang. Project Secretary - Sam Cubberly.   
--Discussed and established use cases.   
--Separately brainstormed UML diagrams before meeting, combined during meeting. Decided on a 6 class structure, dealer, player, deck, card, board, game.  
--Set time for first sprint as May 20, 2025 at 11:59. Each person creates a class (one person does card and deck both), then completes 1-2 methods outlined below.  
--For next meeting:   
---Get stronger git understanding. Determine viability of current class structure and see if any revisions need to be made.   
---Testing development speed to fine tune the next sprint.  
**-5/20 Meeting:**     
--All members present  
--Planned on how to complete the first checkpoint:  
---Decided on a main.rb file to let the game run 1 loop.   
--- Some members were still struggling with git so we spent a lot of time covering that.    
**-5/27 Meeting:**     
--All members present  
--Designated each person to write rspec test cases for another person's class, to make testing more efficient. Outlined down below  
--Designated code-cleaning and refactoring to the people doing tests.  
---ex. Whoever did player testing could refactor player testing   
--Everyone pitched in with methods for the main.rb loop.  
--Removed game class  
**-5/29 Standup and Post-standup:**    
--All members present   
--Went through and claimed all code  
--Made sure that all unclaimed code was deleted  
--Returned authorship to the rightful owner  
--Planned for turning dealer class into a module, and creating a card module for help with the class  
**6/1 Meetings:**    
**--12:00 Meeting**    
---Yunfeng Wang, Sam Cubberly, and Anshuman Ranjan all present.  
---Yunfeng to make the displayer leaderboard method in dealer.rb, Sam to add a timer, and Anshuman to modify main.rb for multiplayer.  
---Everyone else given task test these changes  
**--3:30 Meeting**    
---Anshuman connection wore out, Sam transcribed his newer work into main  
---Fixed bugs in main, and gave everyone tasks for how to finish the project.  

# Team Member Contributions  
**Yunfeng Wang:**    
#Designed part of the Use case and helped design the UML diagram, edit submission to Carmen and github repo.    
#Create board.rb and it's test case, also construct board_spec.rb (deleted).              
#Based on documentation, combine game.rb and class.rb function together, create new main.rb file. Build Rspec file main_spec.rb. Build rspec for player class. Updae Github README.md.    
#add display_leaderboard method, add rspec test cases for dealer.rb. update README.md.
  
**Sam Cubberly:** 
-Helped design the skeleton for the UML diagram and divided up first sprint into 5 tasks.  
-Created the Dealer class, the compare_attributes method, is_player_set_valid method, identify_set_on_board method, and timed_player_input methods  
-Created some test cases in main_spec.rb, contributed heavily in board_spec.rb  
-Created attr_accessor method in board.rb  
-Contributed to logic in main.rb to fix bugs in the most recent version  

**Anshuman Ranjan:** 
Modified Player Class to include the Player.name instance variable (to support multiplayer functionality)
Wrote all the functions in main.rb (integrated some code from other team members, their contributions are listed directly above their specific code in main.rb)
- Created case-when statements to deal with all the user_inputs in the game
- Created create_players method that has a hash of players (created and integrated multiplayer functionality)
- Integrated the display_leaderboard function and timed_user_input functions into main (both those functions written by other team members)
Created test cases for Board class
Standardized the documentation style across all the .rb project files  
  
**Sepehr Hooshiari:**
-Contributed ideas to designing the UML diagram.  
-Created the Player class with the select_set method and refactored code where needed.  
-Created test cases in card_spec.rb and deck_spec.rb and added additional test cases to  
main_spec.rb.  
-Contributed to debugging minor issues with functions in the main class.  
  
**Oliver Shen:**     
-Created the Use Cases part and added 4 Basic user cases and 7 optional user cases based on the project description. Added some detail steps for 5 of the cases.    
-Created and refactor card.rb and deck.rb  
-Created the Dealer Class Rspec  
-Contributed test cases in card_spec.rb, deck_spec.rb, player_spec.rb and main_spec.rb  




# Sprint #1  
  Due by May 20, 2025 at 11:59 pm  
  **Game Class:** Create board, deck, and player reference variables. Create +start() method        
  *#By Anshuman Ranjan*  
    
  **Player Class:** Create score, and valid_score reference variables. Create select_set() method   
  *#By Sepher Hooshiari*  
    
  **Board Class:** Create cards_on_board reference variable. Create display() method.               
  *#By Yunfeng Wang*  
    
  **Card/Deck Class:** Create reference variables for both classes.                                 
  *#By Oliver Shen*  
    
  **Dealer Class:** complete update_board() and identify_set_on_board() methods                     
  *#By Sam Cubberly*  
  
# Sprint #2  
  Due by May 28, 2025 at 11:59 pm  
  **Board Class Rspec:** *#By Anshuman Ranjan*  
  **Card Class Rspec:**  *#By Sepher Hooshiari*   
  **Dealer Class Rspec:** *By Oliver Shen*  
  **Deck Class Rspec:** *By Sepehr Hooshiari*  
  **Player Class Rspec:** *By Yunfeng Wang*  
  **Main File Rspec:** *By Sam Cubberly

  **Writing Main Class Loop:** 
  #Due by May 28, 2025 at 11:59 pm  
 - Create Requirements for additional methods	*By	Sam Cubberly*
 - Create Test Cases for the main class  			*By Yunfeng Wang*
 - Implement additional methods				*By Oliver Shen*
 - Create Main Loop that passes all test cases (Documentation) *By Anshuman Ranjan*
 - Create Main Loop that passes all test cases (Implementation) *By Yunfeng Wang*

  
  
# Sprint #3  
#Due by Jun 1st, 2025 at 11:59 pm  
-Create additional features on main & dealer, *By Anshuman Ranjan, Sam Cubberly, Yunfeng Wang*  
-Add more test cases for all classes, *By Anshuman Ranjan, Sam Cubberly, Yunfeng Wang, Oliver Shen, Sepehr Hooshiari*  
-Wrap up Project 2  
    
  
