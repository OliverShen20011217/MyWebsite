# player.rb
# @author Sepehr Hooshiari
# File created 5/20/25 - Sepehr Hooshiari
# Class is designed to increment a player's score if a set is valid or decrement
# a player's score if a set is invalid
require "./dealer.rb"

# Edit - Sepehr Hooshiari - 5/29
#      Removed setter for @valid_score since @score is only needed in this version of the game

# Edit - Sam Cubberly - 5/30
#      incorporated Dealer as a module to make methodcalls more efficient
class Player

  #Dealer module
  include Dealer

  attr_accessor :score, :name

  # @author Sepehr Hooshiari
  # Edit - Sepehr Hooshiari - 5/29
  #      Removed instance variable @valid_score
  #      Class now represented by <integer> @score
  def initialize(name)
    @name = name
    @score = 0
  end

  #Edit - Sam Cubberly - 5/21
  #      Tested validity using the is_valid_set method in dealer
  #Edit by Yunfeng Wang 5/28
  #     added line 28,32 to return boolean value for rspec test.
  # Edit - Sepehr Hooshiari - 5/29
  #      Removed unnecessary return statements
  #      (note: update player_spec.rb to create valid tests with lack
  #      of extra return statements)
  # Edit - Sam Cubberly - 5/30
  #	changed dealer class calls to dealer module calls
  # @author Sepehr Hooshiari
  # @returns false if @player selects an invalid number of cards,
  # otherwise, increments or decrements based on validity of set
  def select_set(cards)
    unless cards.length == 3
      puts "Player selected an invalid number of cards."
      return false
    end

    if is_player_set_valid cards 
      puts "Valid Set"
       @score += 1
    else  
       puts "Invalid set"
       @score -= 1
    end

  end
end
