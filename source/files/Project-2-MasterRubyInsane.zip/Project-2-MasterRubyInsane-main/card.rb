#card.rb
# @author Oliver Shen
# @created 5/20/2025
# @description Card object for the game of Set. Creates a card containing 4 attributes, each with 3 possible values
# @methods module CardAttributes, initialize, to_s, to_array, to_h

# @edited Oliver Shen 5/20/2025
# @notes: delete the compare funtion and added the to_string function 
# @edited Oliver Shen 5/30/2025
# @notes: 1. Refactored attribute constants into a CardAttributes module for reuse.
#         2. Renamed to_string to the standard to_s for readability.
#         3. Added a to_h method to return the card’s four attributes as a hash.
#         4. Kept to_array for converting each attribute to its numeric index.

# Represents a single Set card with four attributes: number, shading, colour, and symbol.
# Each attribute’s possible values are defined in CardAttributes.
#
# Instance Variables:
# @number  [Symbol]  one of CardAttributes::NUMBERS
# @shading [Symbol]  one of CardAttributes::SHADINGS
# @colour  [Symbol]  one of CardAttributes::COLOURS
# @symbol  [Symbol]  one of CardAttributes::SYMBOLS

# @created 5/30/2025 by Oliver Shen
# @notes: Refactored attribute constants into a CardAttributes module for reuse.
module CardAttributes
  NUMBERS  = %i[one two three].freeze
  SHADINGS = %i[solid striped open].freeze
  COLOURS  = %i[red green purple].freeze
  SYMBOLS  = %i[diamond oval squiggle].freeze
end


class Card
  include CardAttributes

  attr_accessor :number, :shading, :colour, :symbol

  # @created 5/20/2025 by Oliver Shen
  # @param number  [Symbol]  must be one of CardAttributes::NUMBERS
  # @param shading [Symbol]  must be one of CardAttributes::SHADINGS
  # @param colour  [Symbol]  must be one of CardAttributes::COLOURS
  # @param symbol  [Symbol]  must be one of CardAttributes::SYMBOLS
  # initializes the card with a number, shading, color, and symbol
  # @return [Card] new card instance with 1/81 possible unique face values
  def initialize(number, shading, colour, symbol)
    @number, @shading, @colour, @symbol = number, shading, colour, symbol
  end

  # @created 5/20/2025 by Oliver Shen
  # @Edited 5/30/2025 by Oliver ShenRenamed to_string to the standard to_s for readability.
  # prints card attribute to readable string
  # @return <String> ex:"one solid red oval"
  def to_s
    [number, shading, colour, symbol].join(" ")
  end

  # @created 5/20/2025 by Oliver Shen
  # convert the attributes to the corresponding index arrays of 0,1, and 2
  # @return [Array<Integer>] e.g. [0,1,2,0]
  # Why not override Ruby’s built-in to_a?  
  # By convention, to_a on many Ruby objects returns an array of their internal elements.
  # For a Card object, overriding to_a could confuse other code or libraries that expect
  # to_a to convert to an actual Array container. Instead, to_array is a distinct name
  # that clearly signals “convert my four attributes into numeric indices” without risking
  # collision with Ruby’s standard to_a behavior.
  def to_array
    [
      NUMBERS.index(number),
      SHADINGS.index(shading),
      COLOURS.index(colour),
      SYMBOLS.index(symbol)
    ]
  end

  # @created 5/30/2025 by Oliver Shen
  # @notes: Added a to_h method to return the card’s four attributes as a hash.
  # Return a hash representation of this Card’s four attributes.
  #
  # This is useful for debugging, logging, or any external serialization that wants
  # to inspect a card as a simple key/value structure rather than a custom object.
  #
  # Example output:
  #   { number: :two, shading: :solid, colour: :purple, symbol: :diamond }
  #
  # @return [Hash{Symbol => Symbol}]
  #   A hash with keys :number, :shading, :colour, :symbol and corresponding symbol values.

  def to_h
    {
      number:  number,
      shading: shading,
      colour:  colour,
      symbol:  symbol
    }
  end
end





